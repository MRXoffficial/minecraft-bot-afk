// "cap add android" sonrasi calistirilir: uygulama ikonunu (android-ekler/res) Android projesine koyar.
// Sablonun varsayilan ikonlarini siler (ayni adli .png/.webp/.xml cakismasin diye). Tekrar calistirmak guvenlidir.
import { existsSync, readdirSync, copyFileSync, mkdirSync, rmSync, statSync } from 'node:fs'
import { join } from 'node:path'

const KOK = process.env.ANDROID_KOK || 'android'
const HEDEF = join(KOK, 'app/src/main/res')
const KAYNAK = join('android-ekler', 'res')

if (!existsSync(HEDEF)) {
  console.error('HATA: ' + HEDEF + ' bulunamadi. Once "npx cap add android" calistir.')
  process.exit(1)
}
if (!existsSync(KAYNAK)) {
  console.error('HATA: ' + KAYNAK + ' bulunamadi.')
  process.exit(1)
}

// 1) Sablonun eski ikon dosyalarini temizle
for (const k of readdirSync(HEDEF)) {
  if (!k.startsWith('mipmap-')) continue
  const klasor = join(HEDEF, k)
  for (const d of readdirSync(klasor)) {
    if (/^ic_launcher.*\.(png|webp|xml)$/.test(d)) rmSync(join(klasor, d))
  }
}

// 2) Yeni ikonlari kopyala
let sayi = 0
function kopyala(kaynak, hedef) {
  mkdirSync(hedef, { recursive: true })
  for (const x of readdirSync(kaynak)) {
    const a = join(kaynak, x), b = join(hedef, x)
    if (statSync(a).isDirectory()) kopyala(a, b)
    else { copyFileSync(a, b); sayi++ }
  }
}
kopyala(KAYNAK, HEDEF)
console.log('Ikon dosyalari kopyalandi (' + sayi + ' dosya).')
