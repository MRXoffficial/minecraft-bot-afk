// APK'yi kucultur: node_modules/minecraft-data icindeki kullanilmayan Minecraft surumlerinin verilerini siler
// (Bedrock verisi ve kullanmadigin PC surumleri). Kucultmeden once dosyalari yedege tasir; dogrulama
// basarisiz olursa hepsini geri koyar, yani en kotu ihtimalle APK eskisi gibi buyuk kalir.
// Kapatmak icin:  BOYUT_KUCULT=0 npm run hazirla
import { existsSync, readFileSync, readdirSync, lstatSync, mkdirSync, renameSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { execFileSync } from 'node:child_process'

const KOK = 'static/nodejs'
const YEDEK = '.boyut-yedek'   // proje kokunde; APK'ya girmez

const DOGRULA = `
const v = process.argv[1]
const mcData = require('minecraft-data')(v)
if (!mcData) throw new Error('minecraft-data ' + v + ' bulunamadi')
for (const k of ['blocks','blocksArray','items','itemsArray','entities','entitiesArray','biomes','recipes','enchantments','effects','foods','materials','particles','windows','protocol','language','tints','mapIcons','blockCollisionShapes','version','attributes','sounds','commands','loginPacket','supportFeature']) { void mcData[k] }
require('prismarine-registry')(v)
require('prismarine-chunk')(v)
require('prismarine-item')(v)
require('prismarine-block')(v)
require('minecraft-protocol')
require('mineflayer')
console.log('DOGRULAMA_TAMAM')
`

function boyut(yol) {
  let t = 0
  const st = lstatSync(yol)
  if (st.isSymbolicLink()) return 0
  if (st.isDirectory()) { for (const a of readdirSync(yol)) t += boyut(join(yol, a)) } else t = st.size
  return t
}
const mb = (b) => (b / 1048576).toFixed(1) + ' MB'

function surumOku() {
  try {
    const m = readFileSync('node-kaynak/index.js', 'utf8').match(/VERSION:\s*'([^']*)'/)
    return m ? m[1].trim() : ''
  } catch (e) { return '' }
}

// node_modules icinde minecraft-data/minecraft-data/data klasorlerini bul (birden fazla kopya olabilir)
function dataKlasorleri(kok, bulunan = []) {
  if (!existsSync(kok)) return bulunan
  for (const ad of readdirSync(kok)) {
    const yol = join(kok, ad)
    let st
    try { st = lstatSync(yol) } catch (e) { continue }
    if (st.isSymbolicLink() || !st.isDirectory() || ad === '.bin' || ad === '.cache') continue
    if (ad === 'minecraft-data') {
      const data = join(yol, 'minecraft-data', 'data')
      if (existsSync(join(data, 'dataPaths.json'))) bulunan.push(data)
    }
    dataKlasorleri(yol, bulunan)
  }
  return bulunan
}

function dogrula(surum) {
  try {
    const cikti = execFileSync(process.execPath, ['-e', DOGRULA, surum], { cwd: KOK, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
    return cikti.includes('DOGRULAMA_TAMAM') ? null : 'beklenmeyen cikti'
  } catch (e) {
    return String((e.stderr || e.message || e)).split('\n').filter(Boolean).slice(0, 4).join(' | ')
  }
}

export function boyutKucult() {
  if (process.env.BOYUT_KUCULT === '0') { console.log('Boyut kucultme kapali (BOYUT_KUCULT=0)'); return }
  const surum = surumOku()
  if (!surum) { console.log('Boyut kucultme atlandi: node-kaynak/index.js icinde VERSION bos (surum otomatik algilaniyor)'); return }
  const klasorler = dataKlasorleri(join(KOK, 'node_modules'))
  if (!klasorler.length) { console.log('Boyut kucultme atlandi: minecraft-data bulunamadi'); return }

  // 1) Kucultmeden once her sey zaten calisiyor mu? Calismiyorsa dokunma.
  const once = dogrula(surum)
  if (once) { console.log('Boyut kucultme atlandi: kucultmeden once dogrulama basarisiz (' + once + ')'); return }

  const oncekiBoyut = klasorler.reduce((t, d) => t + boyut(d), 0)
  rmSync(YEDEK, { recursive: true, force: true })
  mkdirSync(YEDEK, { recursive: true })
  const tasinan = []   // { from, to }
  const tasi = (from) => {
    const to = join(YEDEK, String(tasinan.length))
    renameSync(from, to)
    tasinan.push({ from, to })
  }
  const geriKoy = () => { for (const { from, to } of tasinan.reverse()) { try { renameSync(to, from) } catch (e) { console.log('GERI KOYMA HATASI: ' + from) } } }

  try {
    for (const data of klasorler) {
      const dp = JSON.parse(readFileSync(join(data, 'dataPaths.json'), 'utf8'))
      const girdi = dp && dp.pc && dp.pc[surum]
      if (!girdi) { console.log('Atlandi (' + data + '): dataPaths icinde pc/' + surum + ' yok'); continue }
      const tut = new Set(['pc/common'])
      for (const v of Object.values(girdi)) if (typeof v === 'string') tut.add(v.split('/').slice(0, 2).join('/'))
      // PC: kullanilan surum klasorleri disindakileri kaldir
      const pc = join(data, 'pc')
      if (existsSync(pc)) for (const ad of readdirSync(pc)) if (!tut.has('pc/' + ad) && lstatSync(join(pc, ad)).isDirectory()) tasi(join(pc, ad))
      // Bedrock: ortak (kucuk) dosyalar kalsin, surum klasorleri kalksin
      const bd = join(data, 'bedrock')
      if (existsSync(bd)) for (const ad of readdirSync(bd)) if (ad !== 'common' && lstatSync(join(bd, ad)).isDirectory()) tasi(join(bd, ad))
    }
    if (!tasinan.length) { console.log('Boyut kucultme: silinecek bir sey bulunamadi'); rmSync(YEDEK, { recursive: true, force: true }); return }

    // 2) Kucultmeden sonra tekrar dogrula; basarisizsa geri koy
    const sonra = dogrula(surum)
    if (sonra) {
      geriKoy()
      rmSync(YEDEK, { recursive: true, force: true })
      console.log('UYARI: kucultme sonrasi dogrulama basarisiz, her sey geri konuldu (APK kucultulmedi): ' + sonra)
      return
    }
    rmSync(YEDEK, { recursive: true, force: true })
    const sonrakiBoyut = klasorler.reduce((t, d) => t + boyut(d), 0)
    console.log('minecraft-data kucultuldu (surum ' + surum + '): ' + mb(oncekiBoyut) + ' -> ' + mb(sonrakiBoyut))
  } catch (e) {
    geriKoy()
    rmSync(YEDEK, { recursive: true, force: true })
    console.log('UYARI: kucultme sirasinda hata, her sey geri konuldu: ' + e.message)
  }
}
