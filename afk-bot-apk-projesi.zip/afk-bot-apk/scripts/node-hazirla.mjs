// node-kaynak/index.js dosyasini static/nodejs/index.js olarak hazirlar.
// Varsayilan: kodu karistirir (obfuscate). Duz kopya icin:  OBF=0 npm run node:hazirla
import { execSync } from 'node:child_process'
import { copyFileSync, mkdirSync, readdirSync, rmSync, existsSync, lstatSync } from 'node:fs'
import { join } from 'node:path'

const kaynak = 'node-kaynak/index.js'
const hedef = 'static/nodejs/index.js'
mkdirSync('static/nodejs', { recursive: true })
temizle('static/nodejs/node_modules')   // her iki yolda da (karistirmali / duz kopya) calisir

if (process.env.OBF === '0') {
  copyFileSync(kaynak, hedef)
  console.log('Duz kopya yapildi (OBF=0): ' + hedef)
  process.exit(0)
}

try {
  execSync(
    'npx --no-install javascript-obfuscator ' + kaynak + ' --output ' + hedef +
    ' --target node --compact true --string-array true --string-array-encoding base64' +
    ' --string-array-threshold 1 --identifier-names-generator hexadecimal',
    { stdio: 'inherit' }
  )
  console.log('Kod karistirildi: ' + hedef)
} catch (e) {
  if (process.env.OBF_ZORUNLU === '1') { console.error('HATA: karistirma basarisiz (OBF_ZORUNLU=1)'); process.exit(1) }
  copyFileSync(kaynak, hedef)
  console.log('UYARI: karistirma basarisiz oldu, duz kopya yapildi: ' + hedef)
}

// Android'in asset birlestiricisi "x" ile "x.gz" dosyalarini ayni sayip hata verir (orn. prismarine-nbt/sample/bigtest.nbt).
// Calismak icin gerekmeyen ornek/test/dokuman klasorlerini de silerek APK'yi kucultur.
function temizle(kok) {
  if (!existsSync(kok)) { console.log('Temizlik atlandi (bulunamadi): ' + kok); return }
  const atilacak = new Set(['sample', 'samples', 'test', 'tests', '__tests__', 'example', 'examples', 'docs', '.github'])
  let silinen = 0
  const gez = (klasor) => {
    for (const ad of readdirSync(klasor)) {
      const yol = join(klasor, ad)
      const s = lstatSync(yol)
      if (s.isSymbolicLink()) continue
      if (s.isDirectory()) {
        if (atilacak.has(ad)) { rmSync(yol, { recursive: true, force: true }); silinen++ } else gez(yol)
      } else if (ad.endsWith('.gz') && existsSync(yol.slice(0, -3))) { rmSync(yol, { force: true }); silinen++ }
    }
  }
  gez(kok)
  console.log('Temizlendi: ' + silinen + ' oge (' + kok + ')')
}
