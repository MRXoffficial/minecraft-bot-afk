# AFK Bot (APK projesi)

Yapımcı: ShibaBey

Oyun hesapları için telefonda çalışan AFK botu. İstediğin kadar AFK hesabı ekleyebilirsin (alttaki **+ Hesap ekle** düğmesi). Her hesap kendi başına çalışır.

**Ne yapar:** Her hesaba giriş yapar (`/login`), 10 saniye sonra `/genpvp` yazarak GenPvP'ye geçer, 10 saniye sonra `/warp afk` yazıp orada yürümeden bekler. Ana hesap, bir AFK hesabına özel mesajla `trade` yazarsa o hesap `/shard` yazıp shard miktarını okur, ana hesaba `/shard buy <ana hesap> <miktar>` gönderir. Aynı anda yalnızca bir hesap işlem yapar.

Şifreler yalnızca telefonda şifreli saklanır ve sunucuya sadece `/login` için gönderilir.

## Önce bilmen gerekenler (dürüst not)

Bu projedeki **Node.js tarafı ve arayüz mantığı** sahte sunucu ve sahte arayüzle baştan sona test edildi (giriş, Prison, `/warp afk`, yürüme, takas, 06:05, kayıt, durdurma). **Android derlemesi ve gerçek telefonda çalışması denenmedi**, çünkü hazırlandığı ortamda Android SDK ve internet yoktu. İlk derlemede hata çıkabilir. Çıkan hatanın tamamını kopyalayıp gönderirsen düzeltilir.

Bilinen riskler:

- Uygulama, Node.js'i telefona gömmek için `capacitor-nodejs` eklentisini kullanır. Eklentinin yazarı artık yeni projelerde önermiyor ve içindeki Node sürümü 18. Mineflayer Node 18'i destekler ama bu bir risk.
- Android, arka plandaki uygulamaları kapatabilir. Bu yüzden projede küçük bir "ön plan servisi" (Java) var. Telefonda **pil kısıtlamasını kapatmak** (uygulamadaki "Pil izni" düğmesi) şart.
- Uygulama büyük olur (yüz MB civarı) ve ilk açılışta dosyalar telefona açıldığı için bir iki dakika sürebilir.
- Mineflayer sürümü sunucunun Minecraft sürümüyle uyumlu olmalı. Termux'taki botunun çalıştığı sürümü kullan: `cd ~/mcbot && npm ls mineflayer` yaz, çıkan sürümü `static/nodejs/package.json` içindeki `mineflayer` satırına yaz.

## Derleme yolu A: GitHub ile (bilgisayara gerek yok)

1. github.com'da ücretsiz hesap aç, **New repository** ile (Private seçebilirsin) boş bir depo oluştur.
2. Bu zip'in içindeki **dosyaların hepsini** (klasörün kendisini değil, içindekileri; `.github` klasörü dahil) depoya yükle. Web arayüzünde "Add file > Upload files" ile sürükle bırak yapabilirsin. `.github` klasörü gizli görünebilir, yüklendiğinden emin ol.
3. Depoda **Actions** sekmesine gir, soldan **APK derle**'yi seç, **Run workflow**'a bas.
4. 10-20 dakika sonra çalışma yeşil olursa, çalışmanın sayfasının altındaki **Artifacts** bölümünden `afk-bot-apk`'yı indir. İçinden `app-debug.apk` çıkar.
5. Kırmızı olursa, hatalı adımı aç, en alttaki hata satırlarını kopyala ve gönder.

Eklenti indirilemezse `package.json` içindeki `capacitor-nodejs` adresindeki sürüm numarasını (`v1.0.0-beta.10`) github.com/hampoelz/Capacitor-NodeJS/releases sayfasındaki en yeni sürümle değiştir.

## Derleme yolu B: Bilgisayarda

Gerekenler: Node.js 22, JDK 21, Android Studio (içindeki Android SDK ile).

```
npm install
npm run node:kur
npm run hazirla
npm run android:ekle
npx cap sync android
cd android
./gradlew assembleDebug        # Windows'ta: gradlew.bat assembleDebug
```

APK şurada çıkar: `android/app/build/outputs/apk/debug/app-debug.apk`

Kodu değiştirdikten sonra tekrar derlemek için kökte `npm run apk` yeterli.

## Uygulama ikonu

İkon `android-ekler/res` içinde hazır (kaynak resim: `ikon/genpvp-ikon.png`). `npm run android:ekle` çalışınca otomatik olarak Android projesine konur, GitHub derlemesinde de aynısı olur. İkonu değiştirmek için `android-ekler/res/mipmap-*` içindeki `ic_launcher*.png` dosyalarını yenile.

## Telefona kurulum ve ilk kullanım

1. APK'yı telefona at, aç. "Bilinmeyen kaynaklardan yükle" izni isteyebilir. Play Protect uyarı verirse "Yine de yükle" de (uygulama Google Play'de yayınlanmış değil).
2. Uygulamayı aç. Takas alacak ana hesabını yaz, AFK hesaplarının kullanıcı adı ve şifresini gir (daha fazla hesap için **+ Hesap ekle**), **Başlat**'a bas.
3. **Pil izni** düğmesine bas, açılan ekranda "Kısıtlama yok" (ya da "İzin ver") seç. Ayarlar'dan bildirim iznini de ver.
4. Ana hesabından `/msg <AFK hesap adı> trade` yazınca o hesap `/shard` ile miktarı okur ve `/shard buy` gönderir.

Günlük bölümü her adımı yazar, bir yerde takılırsa nedenini orada görürsün.

## Yeni sürümü kurma (önemli)

GitHub'da her derleme yeni bir imzayla çıkar. Bu yüzden yeni APK'yı eskisinin üstüne kuramazsın ("Uygulama yüklenmedi" hatası verir). **Önce eski AFK Bot uygulamasını sil, sonra yenisini kur.** Silince kayıtlı hesaplar da gider, yeniden girmen gerekir.

## Ayarlar

Sabit ayarlar `node-kaynak/index.js` dosyasının en üstündeki `A` bölümünde: sunucu adresi, `GENPVP_KOMUTU`, bekleme süreleri, restart saati. Değiştirince `npm run apk` ile yeniden derle.

- Sunucu sürümünü sabitlemek için `VERSION: '1.21.1'` gibi yaz.
- Sunucu sürümü `VERSION: '1.20.4'` olarak sabit. Değiştirmek için aynı satırı düzenle (boş bırakırsan otomatik algılanır).
- Günlük restart zamanlayıcısı kapalıdır. Açmak için `RESTART_SAAT: '06:05'` yaz.

## Kodun karıştırılması

`npm run hazirla` sırasında `node-kaynak/index.js`, `javascript-obfuscator` ile okunması zor hale getirilip `static/nodejs/index.js` olarak yazılır. APK'ya bu karıştırılmış dosya girer. Bu, kodu kopyalamayı zorlaştırır ama imkânsız kılmaz (telefonda çalışan kod her zaman çözülebilir). Karıştırma bir sorun çıkarırsa düz kopya için `OBF=0 npm run node:hazirla` kullan.

Kayıtlı kullanıcı adı ve şifre, uygulamanın özel klasöründe AES-256 ile şifreli saklanır. Anahtar aynı klasörde durduğu için bu, diğer uygulamalara ve yanlışlıkla bakan gözlere karşı korur, telefonu kökten ele geçiren birine karşı değil.

## Sorun giderme

- **Uygulama açılıyor ama "Hazır" yazısı gelmiyor:** Node başlamamış olabilir. Bilgisayardan `adb logcat` ile bak ya da hata mesajını gönder.
- **Bağlanıyor ama atılıyor ya da "unsupported protocol" diyor:** `VERSION` ayarına sunucunun Minecraft sürümünü yaz ve Mineflayer sürümünü yukarıdaki gibi eşitle.
- **GenPvP'ye geçmiyor:** `GENPVP_KOMUTU` ve `GENPVP_BEKLEME` değerlerini kontrol et, günlükte `/genpvp gonderildi` satırı çıkmalı.
- **Takasta "tabela ekranı açılmadı" diyor:** sunucunun tabela paketi farklı olabilir, günlüğü gönder.
- **Birkaç saat sonra bağlantı kopuyor:** pil kısıtlamasının kapalı olduğundan ve bildirimin görünür kaldığından emin ol.

## Klasör yapısı

```
node-kaynak/index.js     bot kodu (okunabilir hali)
static/nodejs/           telefona gömülen Node projesi (package.json burada)
src/                     arayüz (HTML, CSS, JS)
android-ekler/           Java: on plan servisi ve pil izni eklentisi
scripts/                 hazırlama ve Android kurulum betikleri
.github/workflows/       GitHub'da APK derleme ayarı
capacitor.config.json    uygulama adı ve eklenti ayarı
```

## Yazı tipi

Arayüz, SIL Open Font License ile dağıtılan **Pixelify Sans** yazı tipini kullanır (lisans: `src/fonts/PixelifySans-OFL.txt`). Yazı tipi `src/stil.css` içine gömülüdür, internet gerekmez.


## Telegram bildirimleri

Arayüzdeki **Telegram bildirimleri** bölümünden bot token ve sohbet ID girilip hangi olayların bildirileceği seçilir (hesap girişi, atılma/kopma, bakım, shard gönderimi, sorunlar, başlatma/durdurma). Token ve ID cihazda şifreli saklanır. **Test mesajı gönder** ile ayarlar denenir. Aynı mesaj 60 saniye içinde tekrar gönderilmez, mesajlar saniyede en fazla yaklaşık bir tane gönderilir.


## Uygulama boyutu ve bellek

- **APK boyutu:** Derleme sırasında `scripts/boyut-kucult.mjs`, `minecraft-data` içindeki kullanılmayan Minecraft sürümlerinin verilerini siler (yalnızca `VERSION` ayarındaki sürüm ve ortak dosyalar kalır). Silmeden önce ve sonra doğrulama yapar, başarısız olursa her şeyi geri koyar. Kapatmak için `BOYUT_KUCULT=0`. `VERSION` değerini değiştirirsen yeni sürümün verisi otomatik korunur.
- **Bellek (RAM):** Her hesap kendi dünya verisini tutar. `GORUS_MESAFESI: 'tiny'` sunucudan en az chunk istediği için hesap başına bellek kullanımını düşürür.


## Trade başlat (anahtar yerleştirme)

**Trade başlat** düğmesi, çalışan her hesabın sırayla şunları yapmasını sağlar:

1. `/tpa <shard alacak hesap>` gönderir. Alıcı **10 saniye** içinde kabul edip bot ışınlanmazsa trade iptal edilir.
2. `/trade <shard alacak hesap>` gönderir, alıcı kabul edince trade ekranı açılır.
3. Envanterdeki **sadece** `trail_key` / `trial_key` eşyalarını trade ekranına koyar (önce shift+tıkla, olmazsa sol sütunlardaki boş slotlara tek tek).
4. Trade ekranı açıldıktan en az 5 sn sonra 0. slottaki **Takası Kabul Et** düğmesine basar.
5. Onaydan 6 sn sonra (ekran hâlâ açıksa kapatır) anahtarların gidip gitmediğine bakıp sonucu yazar ve `/warp afk` ile geri döner.

Alıcı hesap girilmemişse düğme kapalıdır ve trade yapılmaz. Ayarlar `node-kaynak/index.js` başındadır: `TPA_KOMUTU`, `TRADE_KOMUTU`, `TRADE_ESYA_ADLARI`, `TRADE_ONAY_SLOT`, `TRADE_SOL_SUTUNLAR`, `TRADE_HEDEF_SLOTLAR`. Slot numarası = satır × 9 + sütun (ikisi de 0'dan başlar, sol üst = 0).


## Beacon hesabı (şu an kapalı)

`BEACON_HESAPLAR` listesindeki hesaplar (varsayılan: boş, yani herkes `/warp afk` kullanır; açmak için `['shiba3']` gibi yaz, büyük/küçük harf fark etmez) `/warp afk` yerine `/beacon` yazar ve açılan **Yeniden Doğma Fenerlerin** menüsünde `BEACON_SLOT` (10) slotundaki feneri tıklar. Trade sonrası AFK bölgesine dönüş de bu hesap için aynı yolu kullanır. Shard gönderme ve trade akışları aynı kalır.


## Günlük ödül

Bot her başladığında yerel tarih/saati günlüğe yazar ve hesap başına **son alınan ödül tarihini** şifreli dosyada saklar (uygulama kapansa da kalır). Yerel saat, telefondaki saat diliminden alınır (arayüz Node tarafına bildirir).

AFK bölgesine varınca ve her gün gece yarısı tarih değişince, bugünün ödülü alınmamışsa `/günlüködül` (olmazsa `/gunlukodul`) yazar, menüdeki **ender chest** eşyasına tıklar. Yeşil blok = alınmış. Ödül alınınca tarih kaydedilir ve o gün tekrar denenmez. Ödül alınamazsa saatte bir, günde en fazla 6 kez dener. Ayarlar `node-kaynak/index.js` başında `GUNLUK_*` ile başlar. Telegram'da **Günlük ödül** olayı vardır.


## Sırayla giriş

Hesaplar aynı anda değil **sırayla** girer: bir hesap bağlanıp `/login`, `/genpvp`, `/warp afk` ve günlük ödül işlerini bitirince (ya da bağlantısı kopunca / `SIRA_ZAMAN_ASIMI` dolunca) bir sonraki hesap bağlanır. Bekleyen hesaplar "Sırada" görünür. Yeniden bağlanmalar ve restart saati akışı da aynı sıraya girer. Hesaplar arası bekleme `HESAP_ARALIK`.
