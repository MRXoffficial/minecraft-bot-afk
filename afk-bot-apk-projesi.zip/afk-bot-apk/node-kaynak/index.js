'use strict'
// AFK Bot - Node tarafi (nodejs-mobile icinde calisir).
// Yapimci: ShibaBey
// Arayuz (WebView) ile 'bridge' uzerinden mesajlasir. Birden cok AFK hesabi ayni anda calisabilir.

const { channel, getDataPath } = require('bridge')
const fs = require('fs')
const path = require('path')
const crypto = require('crypto')
const net = require('net')
const mineflayer = require('mineflayer')

// ====== SABIT AYARLAR ======
const A = {
  HOST: 'play.ronemacraft.com',
  PORT: 25565,
  VERSION: '1.20.4',            // sunucu surumu (bos birakirsan otomatik algilanir)
  LOGIN_BEKLEME: 2000,          // girisden kac ms sonra /login
  USEITEM_BEKLEME: 10000,       // /login'den kac ms sonra menu (useitem)
  MENU_ESYA_SLOT: 2,            // lobide menu esyasinin hotbar slotu (1-9)
  SLOT: 22,                     // menude GenPvP'nin slotu (pencere slot numarasi, dogrudan kullanilir)
  TIKLAMA_BEKLEME: 3000,        // menu acildiktan sonra tiklamadan once (uzun tutarsan menu kapanabilir)
  MENU_SONRASI_BEKLEME: 10000,  // GenPvP tiklandiktan sonra /warp afk'a kadar
  WARP_KOMUTU: '/warp afk',
  WARP_BEKLEME: 10000,          // /warp afk'tan sonra isinlanma kontrolune kadar
  WARP_TEKRAR: 0,               // 0 = /warp afk sadece bir kez yazilir
  ISINLANMA_ESIK: 5,            // bu kadar blokdan az yer degistirdiyse isinlanma olmadi say
  RESTART_SAAT: '',             // bos = gunluk restart zamanlayicisi kapali. Istersen '06:05' yaz
  SHARD_OKU_ZAMAN: 5000,       // /shard yazdiktan sonra cevap icin en fazla bekleme
  TRADE_ADIM_BEKLEME: 5000,    // shard okunduktan sonra /shard buy'a kadar
  TRADE_SONRASI_BEKLEME: 5000, // /shard buy'dan sonra /warp afk'a kadar
  TRADE_SONUC_BEKLEME: 5000,    // /shard buy cevabini gunluge yazmak icin dinleme suresi
  TRADE_ARALIK: 60000,
  BAKIM_BEKLEME: 5 * 60 * 60 * 1000,  // bakim mesajinda yeniden denemeden once bekleme (5 saat)
  PROTOKOL_BEKLEME: 60000,            // ag protokolu hatasinda bekleme (1 dk)
  KESILDI_BEKLEME: 60000,             // baglanti kesildi durumunda bekleme (1 dk)
  HESAP_ARALIK: 5000            // birden cok hesapta girisler arasi bekleme (sunucu baglanti sinirina takilmamak icin)
}
// ===========================

// ---------- Zaman (Turkiye UTC+3, Intl gerekmez) ----------
function simdi() {
  const d = new Date(Date.now() + 3 * 3600 * 1000)
  const p2 = (n) => String(n).padStart(2, '0')
  return {
    tarih: d.getUTCFullYear() + '-' + p2(d.getUTCMonth() + 1) + '-' + p2(d.getUTCDate()),
    saat: p2(d.getUTCHours()) + ':' + p2(d.getUTCMinutes()),
    saniyeli: p2(d.getUTCHours()) + ':' + p2(d.getUTCMinutes()) + ':' + p2(d.getUTCSeconds()),
    dk: d.getUTCHours() * 60 + d.getUTCMinutes(),
    sn: d.getUTCSeconds()
  }
}

// Restart penceresindeyse (hedeften 5 dk once ile hedef arasi) hedefe kalan ms, degilse 0
function hedefeKalanMs() {
  if (!A.RESTART_SAAT) return 0
  const t = simdi()
  const [hh, mm] = A.RESTART_SAAT.split(':').map(Number)
  const hedefDk = hh * 60 + mm
  if (t.dk >= hedefDk - 5 && t.dk < hedefDk) return ((hedefDk - t.dk) * 60 - t.sn) * 1000
  return 0
}

const bekle = (ms) => new Promise((r) => setTimeout(r, ms))

// ---------- Gunluk (arayuze gonderilir) ----------
const gunluk = []
function log(m, oturum) {
  const s = simdi().saniyeli + '  ' + (oturum ? '[' + oturum.profil.kullanici + '] ' : '') + m
  gunluk.push(s)
  if (gunluk.length > 400) gunluk.shift()
  try { channel.send('log', s) } catch (e) {}
}

// ---------- Kayit (AES-256-GCM, uygulamanin ozel klasorunde) ----------
const dosyaYolu = (ad) => path.join(getDataPath(), ad)

function anahtarAl() {
  const y = dosyaYolu('k.bin')
  try { return fs.readFileSync(y) } catch (e) {
    const k = crypto.randomBytes(32)
    fs.writeFileSync(y, k)
    return k
  }
}

let profilOnbellek = null
let profilYuklendi = false

function profilKaydet(profil) {
  const iv = crypto.randomBytes(12)
  const c = crypto.createCipheriv('aes-256-gcm', anahtarAl(), iv)
  const enc = Buffer.concat([c.update(JSON.stringify(profil), 'utf8'), c.final()])
  fs.writeFileSync(dosyaYolu('a.bin'), JSON.stringify({ iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), v: enc.toString('base64') }))
  profilOnbellek = profil
  profilYuklendi = true
}

// Kayit bicimi: { alici, otomatik, hesaplar: [{ kullanici, sifre }] }. Eski tek hesapli kayitlari da cevirir.
function profilOku() {
  if (profilYuklendi) return profilOnbellek
  let p = null
  try {
    const d = JSON.parse(fs.readFileSync(dosyaYolu('a.bin'), 'utf8'))
    const dc = crypto.createDecipheriv('aes-256-gcm', anahtarAl(), Buffer.from(d.iv, 'base64'))
    dc.setAuthTag(Buffer.from(d.tag, 'base64'))
    p = JSON.parse(Buffer.concat([dc.update(Buffer.from(d.v, 'base64')), dc.final()]).toString('utf8'))
    if (p && !Array.isArray(p.hesaplar) && p.kullanici) p = { alici: p.alici, otomatik: !!p.otomatik, hesaplar: [{ kullanici: p.kullanici, sifre: p.sifre }] }
    if (p && !Array.isArray(p.hesaplar)) p = null
  } catch (e) { p = null }
  profilOnbellek = p
  profilYuklendi = true
  return p
}

function profilSil() {
  try { fs.unlinkSync(dosyaYolu('a.bin')) } catch (e) {}
  profilOnbellek = null
  profilYuklendi = true
}

// ---------- Metin bilesenleri ve skor tablosu ----------
function nbtSade(x) {
  if (x && typeof x === 'object' && typeof x.type === 'string' && 'value' in x) {
    const t = x.type, v = x.value
    if (t === 'compound') { const o = {}; for (const k in v) o[k] = nbtSade(v[k]); return o }
    if (t === 'list') return (v.value || []).map((e) => nbtSade({ type: v.type, value: e }))
    return v
  }
  return x
}

function bilesenMetni(x) {
  if (x === null || x === undefined) return ''
  if (typeof x === 'string') {
    const t = x.trim()
    if (t[0] === '{' || t[0] === '[' || t[0] === '"') { try { return bilesenMetni(JSON.parse(t)) } catch (e) {} }
    return x
  }
  if (typeof x === 'number' || typeof x === 'boolean') return String(x)
  if (Array.isArray(x)) return x.map(bilesenMetni).join('')
  if (typeof x === 'object') {
    if (typeof x.type === 'string' && 'value' in x) return bilesenMetni(nbtSade(x))
    let s = ''
    if (typeof x.text === 'string') s += x.text
    else if (x.text !== undefined) s += bilesenMetni(x.text)
    if (!s && typeof x.translate === 'string') s += x.translate
    if (x.extra !== undefined) s += bilesenMetni(x.extra)
    return s
  }
  return ''
}

function skorTemizle(s) {
  return String(s).replace(/§[0-9a-fk-or]/gi, '').replace(/[\uE000-\uF8FF]/g, '').replace(/\s+/g, ' ').trim()
}

// ---------- Skor tablosu (her hesap icin ayri takip edilir) ----------
function bosSkor() { return { hedefler: {}, sidebar: null, skorlar: {}, takimlar: {}, oyuncuTakim: {} } }

function skorTakipBaslat(s, bot) {
  const c = bot._client
  if (!c) return
  const d = s.skor = bosSkor()
  c.on('scoreboard_objective', (p) => {
    if (p.action === 1) delete d.hedefler[p.name]
    else d.hedefler[p.name] = bilesenMetni(p.displayText)
  })
  c.on('scoreboard_display_objective', (p) => {
    if (p.position === 1 || p.position === 'sidebar') d.sidebar = p.name || null
  })
  c.on('scoreboard_score', (p) => {
    const hedef = p.scoreName !== undefined ? p.scoreName : p.objective_name
    const isim = p.itemName !== undefined ? p.itemName : p.entity_name
    if (hedef === undefined || isim === undefined) return
    if (p.action === 1) { if (d.skorlar[hedef]) delete d.skorlar[hedef][isim]; return }
    if (!d.skorlar[hedef]) d.skorlar[hedef] = {}
    d.skorlar[hedef][isim] = { deger: Number(p.value) || 0, gosterim: (p.display_name !== undefined && p.display_name !== null) ? bilesenMetni(p.display_name) : '' }
  })
  c.on('reset_score', (p) => {
    const hedef = p.scoreName !== undefined ? p.scoreName : (p.objective_name !== undefined ? p.objective_name : p.objectiveName)
    const isim = p.itemName !== undefined ? p.itemName : (p.entity_name !== undefined ? p.entity_name : p.entityName)
    if (isim === undefined) return
    if (hedef !== undefined && hedef !== null) { if (d.skorlar[hedef]) delete d.skorlar[hedef][isim] }
    else for (const h in d.skorlar) delete d.skorlar[h][isim]
  })
  const takimIsleyici = (p) => {
    const ad = p.team
    if (!ad) return
    const mod = typeof p.mode === 'number' ? ['add', 'remove', 'change', 'join', 'leave'][p.mode] : p.mode
    const oyuncular = Array.isArray(p.players) ? p.players : []
    if (mod === 'remove') {
      const t = d.takimlar[ad]
      if (t) t.oyuncular.forEach((o) => { delete d.oyuncuTakim[o] })
      delete d.takimlar[ad]
      return
    }
    let t = d.takimlar[ad]
    if (!t) t = d.takimlar[ad] = { prefix: '', suffix: '', oyuncular: [] }
    if (mod === 'add' || mod === 'change') { t.prefix = bilesenMetni(p.prefix); t.suffix = bilesenMetni(p.suffix) }
    if (mod === 'add' || mod === 'join') oyuncular.forEach((o) => { if (!t.oyuncular.includes(o)) t.oyuncular.push(o); d.oyuncuTakim[o] = ad })
    if (mod === 'leave') oyuncular.forEach((o) => { t.oyuncular = t.oyuncular.filter((x) => x !== o); delete d.oyuncuTakim[o] })
  }
  c.on('teams', takimIsleyici)
  c.on('scoreboard_team', takimIsleyici)
}

function skorSatirlari(s) {
  const d = s.skor
  const hedef = d.sidebar
  if (!hedef) return null
  const ogeler = Object.entries(d.skorlar[hedef] || {}).sort((a, b) => b[1].deger - a[1].deger)
  const satirlar = []
  for (const [isim, o] of ogeler) {
    let metin
    if (o.gosterim) metin = o.gosterim
    else {
      const t = d.takimlar[d.oyuncuTakim[isim]]
      metin = (t ? t.prefix : '') + isim + (t ? t.suffix : '')
    }
    const temiz = skorTemizle(metin)
    if (temiz) satirlar.push(temiz)
  }
  return { baslik: skorTemizle(d.hedefler[hedef] || hedef), satirlar }
}

function skorYazdir(s) {
  const t = skorSatirlari(s)
  if (!t) { log('Skor tablosu henuz gelmedi (GenPvP\'ye gectikten sonra dene)', s); return }
  log('Skor tablosu: ' + t.baslik, s)
  t.satirlar.forEach((l) => log('   ' + l, s))
}

// ---------- Sayi cevirme (32.7K -> 32700) ----------
const KUCUK_HARF = { 'ᴀ': 'A', 'ʙ': 'B', 'ᴄ': 'C', 'ᴅ': 'D', 'ᴇ': 'E', 'ꜰ': 'F', 'ɢ': 'G', 'ʜ': 'H', 'ɪ': 'I', 'ᴊ': 'J', 'ᴋ': 'K', 'ʟ': 'L', 'ᴍ': 'M', 'ɴ': 'N', 'ᴏ': 'O', 'ᴘ': 'P', 'ǫ': 'Q', 'ʀ': 'R', 'ꜱ': 'S', 'ᴛ': 'T', 'ᴜ': 'U', 'ᴠ': 'V', 'ᴡ': 'W', 'ʏ': 'Y', 'ᴢ': 'Z', 'ı': 'I', 'İ': 'I', 'Ü': 'U', 'ü': 'U', 'Ö': 'O', 'ö': 'O', 'Ç': 'C', 'ç': 'C', 'Ş': 'S', 'ş': 'S', 'Ğ': 'G', 'ğ': 'G' }
const BIRIMLER = { '': 1, K: 1e3, M: 1e6, B: 1e9, T: 1e12 }

function duzYazi(s) {
  return String(s).split('').map((c) => KUCUK_HARF[c] || c).join('').toUpperCase()
}

function kisaSayiCoz(metin) {
  const m = String(metin).trim().match(/^([\d.,]+)\s*([A-Z]*)$/)
  if (!m) return null
  const birim = m[2]
  if (!(birim in BIRIMLER)) return null
  const sayi = birim ? m[1].replace(',', '.') : m[1].replace(/[.,]/g, '')
  const v = Number(sayi)
  if (!isFinite(v)) return null
  return Math.round(v * BIRIMLER[birim])
}

function skorDegeri(s, anahtar) {
  const t = skorSatirlari(s)
  if (!t) return null
  const a = duzYazi(anahtar)
  for (const satir of t.satirlar) {
    const d = duzYazi(satir)
    const i = d.indexOf(a)
    if (i < 0) continue
    const kalan = d.slice(i + a.length).replace(/^[\s:]+/, '')
    const sayi = kisaSayiCoz(kalan)
    if (sayi !== null) return { satir, kalan, sayi }
  }
  return null
}

// ---------- Oturumlar (her AFK hesabi icin bir tane) ----------
let elleDurduruldu = false   // kullanici Durdur'a bastiysa uygulama yeniden acilana kadar otomatik baslatma yapma
const oturumlar = new Map()  // kucuk harfli kullanici adi -> oturum

function canli(s, bot) { return !!s && s.calisiyor && s.bot === bot && (!!bot.entity || !!s.girisYapildi) }

function asamaYaz(s, asama) {
  s.asama = asama
  durumGonder()
}

function durumGonder() {
  const k = profilOku()
  const liste = ((k && k.hesaplar) || []).map((h) => {
    const s = oturumlar.get(h.kullanici.toLowerCase())
    return { kullanici: h.kullanici, sifreKayitli: !!h.sifre, calisiyor: !!(s && s.calisiyor), asama: s ? s.asama : 'Durdu' }
  })
  for (const s of oturumlar.values()) {
    if (!liste.some((h) => h.kullanici.toLowerCase() === s.profil.kullanici.toLowerCase())) liste.push({ kullanici: s.profil.kullanici, sifreKayitli: true, calisiyor: s.calisiyor, asama: s.asama })
  }
  try {
    channel.send('durum', {
      calisiyor: oturumlar.size > 0,
      calisanSayisi: oturumlar.size,
      kayitli: !!k,
      alici: k ? k.alici : '',
      otomatik: k ? !!k.otomatik : false,
      hesaplar: liste
    })
  } catch (e) {}
}

// ---------- Warp ----------
// /warp afk yazar, WARP_BEKLEME sonra konum degisimini gunluge yazar ve devam eder (yurume yok)
function warpGit(s, bot, deneme, sonra) {
  const once = bot.entity ? { x: bot.entity.position.x, y: bot.entity.position.y, z: bot.entity.position.z } : null
  try { bot.chat(A.WARP_KOMUTU); log(A.WARP_KOMUTU + ' gonderildi' + (deneme > 0 ? ' (tekrar ' + deneme + ')' : ''), s) } catch (e) {}
  setTimeout(() => {
    if (!canli(s, bot)) return
    let tasindi = true
    if (once && bot.entity) {
      const p = bot.entity.position
      const mesafe = Math.hypot(p.x - once.x, p.y - once.y, p.z - once.z)
      tasindi = mesafe >= A.ISINLANMA_ESIK
      log('Isinlanma kontrolu: ' + mesafe.toFixed(1) + ' blok ' + (tasindi ? '(tamam)' : '(isinlanma gorunmuyor)'), s)
    }
    if (!tasindi && deneme < A.WARP_TEKRAR) { warpGit(s, bot, deneme + 1, sonra); return }
    sonra()
  }, A.WARP_BEKLEME)
}

// ---------- Shard gonderimi ----------
// Sohbet satirlarini ms kadar toplar; erken(satir) true donerse hemen biter
function sohbetTopla(bot, ms, erken) {
  return new Promise((coz) => {
    const satirlar = []
    let bitti = false
    let z = null
    const dinle = (m, p) => {
      if (p === 'game_info') return
      const t = skorTemizle(m)
      if (!t) return
      satirlar.push(t)
      if (erken && erken(t)) bitir()
    }
    const bitir = () => {
      if (bitti) return
      bitti = true
      clearTimeout(z)
      bot.removeListener('messagestr', dinle)
      coz(satirlar)
    }
    z = setTimeout(bitir, ms)
    bot.on('messagestr', dinle)
  })
}

// "Shard: 1250", "1.250 shard", "Shards: 1.2K" gibi satirlardan miktari cikarir (yoksa null)
function shardMiktari(satir) {
  const m = satir.match(/shards?[^\d\n]{0,20}?(\d[\d.,]*)\s*([KMBT])?(?![A-Za-z])/i) || satir.match(/(\d[\d.,]*)\s*([KMBT])?\s*shards?/i)
  if (!m) return null
  const v = kisaSayiCoz(m[1] + (m[2] ? m[2].toUpperCase() : ''))
  return v === null ? null : Math.floor(v)
}

async function shardOku(s, bot) {
  const toplama = sohbetTopla(bot, A.SHARD_OKU_ZAMAN, (t) => /shard/i.test(t) && shardMiktari(t) !== null)
  bot.chat('/shard')
  log('/shard gonderildi, cevap bekleniyor', s)
  const satirlar = await toplama
  for (const t of satirlar) {
    const v = shardMiktari(t)
    if (v !== null && /shard/i.test(t)) { log('/shard cevabi: ' + t, s); return v }
  }
  log('/shard cevabindan miktar okunamadi. Gelen satirlar: ' + (satirlar.length ? satirlar.slice(0, 6).join(' | ') : '(hic mesaj gelmedi)'), s)
  return null
}

async function tradeAfkaDon(s, bot) {
  if (!canli(s, bot)) { log('AFK donus iptal: bot sunucuda degil', s); return }
  try { if (bot.currentWindow) bot.closeWindow(bot.currentWindow) } catch (e) {}
  // /tpa kullanilmadigi icin bot yerinden ayrilmaz, tekrar warp gerekmez
  log('Shard islemi bitti', s)
  asamaYaz(s, 'AFK bolgesinde')
}

// Ayni anda yalnizca tek hesap takas yapar (alici hesap ayni anda iki takasta olamaz); digerleri sirada bekler.
let tradeKuyruk = Promise.resolve()
let tradeKuyrukSayisi = 0

function tradeIste(s, bot, kaynak) {
  if (!s.profil.alici) { log('Takas yapilmadi: shard alacak hesap girilmemis', s); return }
  if (!canli(s, bot)) { log('Takas yapilamadi: bot sunucuda degil', s); return }
  if (s.tradeMesgul || s.tradeSirada) { log('Takas zaten suruyor ya da sirada', s); return }
  const gecen = Date.now() - s.sonTradeZamani
  if (gecen < A.TRADE_ARALIK) { log('Takas cok sik istendi, ' + Math.ceil((A.TRADE_ARALIK - gecen) / 1000) + ' sn sonra tekrar dene', s); return }
  s.tradeSirada = true
  if (tradeKuyrukSayisi > 0) log('Takas sirada: onunde ' + tradeKuyrukSayisi + ' hesap var (ayni anda tek takas yapilir)', s)
  tradeKuyrukSayisi++
  tradeKuyruk = tradeKuyruk
    .then(() => tradeCalistir(s, bot, kaynak))
    .catch(() => {})
    .then(() => { tradeKuyrukSayisi-- })
}

async function tradeCalistir(s, bot, kaynak) {
  s.tradeSirada = false
  if (!s.profil.alici) return
  if (!canli(s, bot)) { log('Shard gonderilemedi: bot sunucuda degil', s); return }
  const alici = s.profil.alici
  s.tradeMesgul = true
  s.sonTradeZamani = Date.now()
  try {
    asamaYaz(s, 'Shard gonderiliyor')
    log('SHARD gonderimi basladi (' + kaynak + ') -> alici: ' + alici, s)
    const miktar = await shardOku(s, bot)
    if (!canli(s, bot)) return
    if (!miktar || miktar < 1) { log('SHARD: miktar okunamadi ya da 0, gonderim iptal', s); return }
    log('SHARD miktari: ' + miktar, s)
    await bekle(A.TRADE_ADIM_BEKLEME)
    if (!canli(s, bot)) return
    const sonuc = sohbetTopla(bot, A.TRADE_SONUC_BEKLEME)
    bot.chat('/shard buy ' + alici + ' ' + miktar)
    log('/shard buy ' + alici + ' ' + miktar + ' gonderildi', s)
    const cevap = await sonuc
    cevap.slice(0, 4).forEach((t) => log('Sunucu: ' + t, s))
  } catch (e) {
    log('SHARD hata: ' + e.message, s)
  } finally {
    try { await tradeAfkaDon(s, bot) } catch (e) { log('AFK donus hatasi: ' + e.message, s) }
    s.tradeMesgul = false
  }
}

// Ozel mesaj "<alici> ... trade" ise takasi baslatir (sadece alici hesaptan)
function tradeMesajKontrol(s, bot, msg) {
  if (!s.profil.alici) return
  const temiz = skorTemizle(msg)
  if (!/trade/i.test(temiz)) return
  const ad = s.profil.alici.replace(/[^A-Za-z0-9_]/g, '')
  const uygun = new RegExp('^[^A-Za-z0-9_]*' + ad + '(?![A-Za-z0-9_])', 'i').test(temiz) && /\btrade\s*$/i.test(temiz)
  if (uygun) { log('Takas mesaji alindi: ' + temiz, s); tradeIste(s, bot, 'mesaj') }
}

// ---------- Baglanti ve AFK dongusu ----------
function prisonAkisi(s, bot, kaynak) {
  if (!canli(s, bot)) return
  if (Date.now() - s.sonAkisZamani < 120000) return
  s.sonAkisZamani = Date.now()
  s.tiklandi = false
  log('GenPvP akisi basladi (' + kaynak + ')', s)
  asamaYaz(s, 'GenPvP\'ye geciliyor')
  try { bot.setQuickBarSlot(A.MENU_ESYA_SLOT - 1) } catch (e) {}
  let deneme = 0
  const dene = () => {
    if (!canli(s, bot) || s.tiklandi) return
    deneme++
    let el = 'bos'
    try { if (bot.heldItem) el = (bot.heldItem.displayName || bot.heldItem.name) } catch (e) {}
    try { s.useitemGitti = true; bot.activateItem(); log('useitem gonderildi (deneme ' + deneme + '), elde: ' + el, s) } catch (e) { log('useitem hatasi: ' + e.message, s) }
    setTimeout(() => {
      if (!canli(s, bot) || s.tiklandi) return
      if (deneme < 3) dene()
      else log('Menu penceresi acilmadi (3 deneme). Elde: ' + el + ' | MENU_ESYA_SLOT=' + A.MENU_ESYA_SLOT + ' dogru mu kontrol et', s)
    }, 7000)
  }
  setTimeout(dene, 500)
}

function sureYazi(ms) {
  if (ms >= 3600000) return (ms / 3600000) + ' saat'
  if (ms >= 60000) return (ms / 60000) + ' dk'
  return (ms / 1000) + ' sn'
}

// Atilma / hata / kopma sebebine gore yeniden deneme suresi (oncelik: bakim > ag protokolu > baglanti kesildi)
function kopmaSebebi(metin) {
  if (/bak[ıiİI]m|maintenance/i.test(metin)) return { asama: 'Sunucu bakimda', ad: 'Sunucu bakimda', bekleme: A.BAKIM_BEKLEME }
  if (/a[ğg]\s*protokol|network protocol|protocol error|PartialReadError|Unexpected buffer|Chunk size/i.test(metin)) return { asama: 'Ag protokolu hatasi', ad: 'Ag protokolu hatasi', bekleme: A.PROTOKOL_BEKLEME }
  if (/ba[ğg]lant[ıi]\s*kesil|connection lost|disconnected|socketClosed|ECONNRESET|ETIMEDOUT|timed? ?out|EPIPE/i.test(metin)) return { asama: 'Baglanti kesildi', ad: 'Baglanti kesildi', bekleme: A.KESILDI_BEKLEME }
  return null
}

function baglan(s) {
  if (!s.calisiyor) return
  s.sebepler = []
  asamaYaz(s, 'Baglaniyor')
  log('Baglaniyor: ' + A.HOST, s)
  let bot
  try {
    bot = mineflayer.createBot({
      host: A.HOST,
      port: A.PORT,
      username: s.profil.kullanici,
      auth: 'offline',
      ...(A.VERSION ? { version: A.VERSION } : {}),
      // SRV aramasini atla, dogrudan TCP baglantisi kur (Android'de DNS/SRV takilmasina karsi)
      connect: (client) => {
        log('TCP baglantisi deneniyor...', s)
        const sock = net.connect({ host: A.HOST, port: A.PORT })
        sock.setTimeout(15000, () => { log('TCP zaman asimi (15 sn): sunucuya ulasilamiyor', s); sock.destroy() })
        sock.on('connect', () => { sock.setTimeout(0); log('TCP baglantisi kuruldu', s) })
        sock.on('error', (e) => log('Soket hatasi: ' + e.message, s))
        client.setSocket(sock)
        client.emit('connect')
      }
    })
  } catch (e) {
    log('createBot hatasi: ' + e.message, s)
    s.timer = setTimeout(() => baglan(s), 10000)
    return
  }
  s.bot = bot
  bot.once('login', () => log('Sunucuya el sikisma tamam (login)', s))

  // ---- Tani gunlukleri: login sonrasi spawn gelmezse nedenini gostermek icin ----
  const paketler = []
  let spawnGeldi = false
  try {
    bot._client.on('packet', (data, meta) => {
      if (spawnGeldi || !meta || paketler.length >= 60) return
      if (paketler[paketler.length - 1] !== meta.name) paketler.push(meta.name)
    })
  } catch (e) {}
  bot.once('spawn', () => { spawnGeldi = true; log('spawn olayi geldi', s) })
  bot.once('login', () => {
    setTimeout(() => {
      if (!spawnGeldi && !s.girisYapildi && s.bot === bot) log('Login sonrasi 20 sn: spawn gelmedi. Gelen paketler: ' + (paketler.join(', ') || '(yok)'), s)
    }, 20000)
  })
  bot.on('messagestr', (m, p) => { if (p !== 'game_info' && (!s.girisYapildi || Date.now() < s.sohbetDinleBitis)) { const t = skorTemizle(m); if (t) log('Sunucu: ' + t, s) } })
  // Texture / resource pack istegini otomatik kabul et (3 = kabul edildi, 4 = indirildi, 0 = basariyla yuklendi)
  const rpKabul = (paket) => {
    const uuid = paket && paket.uuid
    log('Texture pack istegi geldi, kabul ediliyor', s)
    const yaz = (sonuc) => {
      try { bot._client.write('resource_pack_receive', uuid ? { uuid, result: sonuc } : { result: sonuc }) } catch (e) { log('Texture pack yaniti gonderilemedi: ' + e.message, s) }
    }
    setTimeout(() => yaz(3), 300)
    setTimeout(() => yaz(4), 800)
    setTimeout(() => { yaz(0); log('Texture pack kabul edildi', s) }, 1300)
  }
  try {
    bot._client.on('add_resource_pack', rpKabul)    // 1.20.3 ve uzeri
    bot._client.on('resource_pack_send', rpKabul)   // eski surumler
  } catch (e) {}
  bot.on('end', (r) => log('Baglanti kapandi: ' + (r || '(sebep yok)'), s))
  s.girisYapildi = false
  s.useitemGitti = false
  s.tiklandi = false
  skorTakipBaslat(s, bot)
  bot.on('messagestr', (m, p) => { if (p !== 'game_info') tradeMesajKontrol(s, bot, m) })

  // 'spawn' olayi bazi surum donusumlerinde hic gelmeyebiliyor; spawn, position paketi veya login+8 sn: hangisi once gelirse
  const girisBaslat = (kaynak) => {
    if (!s.calisiyor || s.bot !== bot || s.girisYapildi) return
    s.girisYapildi = true
    log('Sunucuya girildi (' + kaynak + ')', s)
    asamaYaz(s, 'Giris yapiliyor')
    setTimeout(() => {
      if (!s.calisiyor || s.bot !== bot) return
      try { bot.chat('/login ' + s.profil.sifre); log('/login gonderildi', s) } catch (e) {}
    }, A.LOGIN_BEKLEME)
    const normal = A.LOGIN_BEKLEME + A.USEITEM_BEKLEME
    const restart = hedefeKalanMs()
    if (restart > normal) log('Restart saati bekleniyor: ' + A.RESTART_SAAT + ' (' + Math.round(restart / 1000) + ' sn)', s)
    setTimeout(() => prisonAkisi(s, bot, 'giris'), Math.max(normal, restart))
  }
  bot.on('spawn', () => girisBaslat('spawn'))
  try { bot._client.once('position', () => setTimeout(() => girisBaslat('position paketi'), 3000)) } catch (e) {}
  bot.once('login', () => setTimeout(() => girisBaslat('login + 8 sn'), 8000))

  bot.on('windowOpen', (win) => {
    if (!canli(s, bot) || !s.useitemGitti || s.tiklandi) return
    if (s.tradeMesgul) return
    s.tiklandi = true
    try {
      let baslik = ''
      try { baslik = skorTemizle(bilesenMetni(win.title)) } catch (e) { baslik = String(win.title) }
      const ust = (typeof win.inventoryStart === 'number') ? win.inventoryStart : win.slots.length
      const liste = []
      for (let i = 0; i < ust; i++) { const it = win.slots[i]; if (it) liste.push(i + ':' + (it.displayName || it.name)) }
      log('Menu penceresi acildi: "' + baslik + '" (' + ust + ' slot). Dolu slotlar: ' + (liste.join(', ') || '(henuz bos)'), s)
    } catch (e) {}
    setTimeout(async () => {
      if (!canli(s, bot)) return
      try {
        const w = bot.currentWindow
        if (!w) log('Uyari: tiklama aninda menu penceresi kapali (currentWindow yok)', s)
        const hedef = (w && w.slots && w.slots[A.SLOT]) ? (w.slots[A.SLOT].displayName || w.slots[A.SLOT].name) : '(bos/yok)'
        // clickWindow sunucu onayi gelmezse asili kalabiliyor; 4 sn'den sonra devam et
        const sonuc = await Promise.race([
          bot.clickWindow(A.SLOT, 0, 0).then(() => 'tamam'),
          new Promise((r) => setTimeout(() => r('onay gelmedi'), 4000))
        ])
        log('Slot ' + A.SLOT + ' tiklandi (' + hedef + ') [' + sonuc + ']', s)
      } catch (e) {
        log('Tiklama hatasi: ' + e.message + ' - yine de devam ediliyor', s)
      }
      setTimeout(() => {
        if (!canli(s, bot)) return
        asamaYaz(s, 'Warp AFK\'ya gidiliyor')
        warpGit(s, bot, 0, () => { asamaYaz(s, 'AFK bolgesinde') })
      }, A.MENU_SONRASI_BEKLEME)
    }, A.TIKLAMA_BEKLEME)
  })

  bot.on('kicked', (r) => {
    const sebep = skorTemizle(bilesenMetni(r))
    log('Atildi: ' + sebep, s)
    s.sebepler.push(sebep)
  })
  bot.on('error', (e) => { log('Hata: ' + e.message, s); s.sebepler.push(String(e && e.message)) })
  bot.on('end', (r) => {
    if (!s.calisiyor || s.bot !== bot) return
    const k = kopmaSebebi(s.sebepler.join(' | ') + ' | ' + String(r || ''))
    if (k) {
      asamaYaz(s, k.asama)
      log(k.ad + ', ' + sureYazi(k.bekleme) + ' sonra tekrar denenecek', s)
      s.timer = setTimeout(() => baglan(s), k.bekleme)
      return
    }
    asamaYaz(s, 'Yeniden baglaniyor')
    log('Baglanti koptu, 10 sn sonra tekrar denenecek', s)
    s.timer = setTimeout(() => baglan(s), 10000)
  })
}

// gecikme > 0 ise hesap "Sirada" olarak gorunur ve o kadar sonra baglanir (sunucu baglanti sinirina takilmamak icin)
function hesapBaslat(h, alici, kaynak, gecikme) {
  const anahtar = h.kullanici.toLowerCase()
  if (oturumlar.has(anahtar)) return
  const s = {
    profil: { kullanici: h.kullanici, sifre: h.sifre, alici },
    bot: null, calisiyor: true, asama: gecikme ? 'Sirada' : 'Baslatiliyor', timer: null,
    tradeMesgul: false, tradeSirada: false, sonTradeZamani: 0, sonAkisZamani: 0, sonZamanlayiciTarih: '',
    sebepler: [], girisYapildi: false, useitemGitti: false, tiklandi: false, sohbetDinleBitis: 0, skor: bosSkor()
  }
  oturumlar.set(anahtar, s)
  log('Baslatildi (' + kaynak + ')' + (gecikme ? ', ' + Math.round(gecikme / 1000) + ' sn sonra baglanacak' : ''), s)
  s.timer = setTimeout(() => baglan(s), gecikme)
}

function hepsiniBaslat(profil, kaynak) {
  let sira = 0
  for (const h of profil.hesaplar) {
    if (oturumlar.has(h.kullanici.toLowerCase())) continue
    hesapBaslat(h, profil.alici, kaynak, sira * A.HESAP_ARALIK)
    sira++
  }
  if (profil.hesaplar.length > 10) log('Uyari: ' + profil.hesaplar.length + ' hesap telefonu yorabilir')
  durumGonder()
}

function hesapDurdur(s, sebep) {
  s.calisiyor = false
  clearTimeout(s.timer)
  s.asama = 'Durdu'
  try { if (s.bot) s.bot.quit() } catch (e) {}
  oturumlar.delete(s.profil.kullanici.toLowerCase())
  log('Durduruldu' + (sebep ? ' (' + sebep + ')' : ''), s)
}

function hepsiniDurdur(sebep) {
  for (const s of Array.from(oturumlar.values())) hesapDurdur(s, sebep)
  durumGonder()
}

// Her gun RESTART_SAAT'te bagli her hesap icin GenPvP akisini bastan calistir
setInterval(() => {
  const t = simdi()
  if (!A.RESTART_SAAT || t.saat !== A.RESTART_SAAT) return
  for (const s of oturumlar.values()) {
    if (!s.calisiyor || s.sonZamanlayiciTarih === t.tarih) continue
    s.sonZamanlayiciTarih = t.tarih
    if (s.bot && canli(s, s.bot) && !s.tradeMesgul) {
      log('Zamanlayici ' + A.RESTART_SAAT + ': lobiden GenPvP\'ye geciliyor', s)
      prisonAkisi(s, s.bot, 'zamanlayici')
    } else {
      log('Zamanlayici ' + A.RESTART_SAAT + ': bagli degil, baglaninca akis kendiliginden calisir', s)
    }
  }
}, 10000)

// ---------- Arayuzden gelen mesajlar ----------
const adGecerli = (s) => /^[A-Za-z0-9_]{3,16}$/.test(s || '')

channel.addListener('hazir', () => {
  channel.send('gecmis', gunluk.slice())
  durumGonder()
  const k = profilOku()
  if (k && k.otomatik && oturumlar.size === 0 && !elleDurduruldu) hepsiniBaslat(k, 'otomatik baslatma')
})

channel.addListener('baslat', (veri) => {
  try {
    veri = veri || {}
    const gelen = Array.isArray(veri.hesaplar) ? veri.hesaplar : []
    if (gelen.length === 0) { channel.send('hata', 'En az bir AFK hesabi ekle.'); return }
    const alici = String(veri.alici || '').trim()
    if (alici && !adGecerli(alici)) { channel.send('hata', 'Shard alacak hesap adi 3-16 karakter olmali (harf, rakam, alt cizgi). Takas istemiyorsan bos birak.'); return }
    const kayit = profilOku()
    const kayitliSifre = (ad) => {
      const h = kayit && kayit.hesaplar.find((x) => x.kullanici.toLowerCase() === ad.toLowerCase())
      return h ? h.sifre : ''
    }
    const gorulen = new Set()
    const hesaplar = []
    for (const h of gelen) {
      const ad = String((h && h.kullanici) || '').trim()
      if (!adGecerli(ad)) { channel.send('hata', '"' + ad + '" gecerli bir hesap adi degil (3-16 karakter, harf, rakam, alt cizgi).'); return }
      if (gorulen.has(ad.toLowerCase())) { channel.send('hata', ad + ' hesabi birden fazla kez eklenmis.'); return }
      if (alici && ad.toLowerCase() === alici.toLowerCase()) { channel.send('hata', 'Shard alacak hesap (' + ad + ') AFK hesaplarindan biri olamaz.'); return }
      let sifre = String((h && h.sifre) || '')
      if (!sifre) sifre = kayitliSifre(ad)
      if (!sifre) { channel.send('hata', ad + ' icin sifre girilmeli.'); return }
      if (sifre.length > 64 || /\s/.test(sifre)) { channel.send('hata', ad + ' sifresi bosluk icermemeli ve en fazla 64 karakter olmali.'); return }
      gorulen.add(ad.toLowerCase())
      hesaplar.push({ kullanici: ad, sifre })
    }
    const profil = { alici, otomatik: !!veri.otomatik, hesaplar }
    profilKaydet(profil)
    elleDurduruldu = false
    hepsiniBaslat(profil, 'elle')
  } catch (e) { channel.send('hata', 'Baslatilamadi: ' + e.message) }
})

// Arayuzden bir AFK hesabinin sohbetine yazi / komut gonder
channel.addListener('sohbet', (veri) => {
  try {
    veri = veri || {}
    const ad = String(veri.kullanici || '').trim().toLowerCase()
    const mesaj = String(veri.mesaj || '').replace(/[\r\n\u0000-\u001f]/g, ' ').trim().slice(0, 256)
    if (!mesaj) return
    const s = oturumlar.get(ad)
    if (!s) { log('Mesaj gonderilemedi: ' + (veri.kullanici || '?') + ' hesabi calismiyor'); return }
    if (!s.bot || !canli(s, s.bot)) { log('Mesaj gonderilemedi: bot sunucuda degil', s); return }
    s.sohbetDinleBitis = Date.now() + 8000   // cevabi gunluge yaz
    s.bot.chat(mesaj)
    log('Gonderildi: ' + (/^\/(login|l|register|reg|changepassword|cp)\b/i.test(mesaj) ? mesaj.split(/\s+/)[0] + ' ***' : mesaj), s)
  } catch (e) { log('Mesaj gonderilemedi: ' + e.message) }
})

channel.addListener('durdur', () => { elleDurduruldu = true; hepsiniDurdur('elle') })

channel.addListener('trade', () => {
  if (oturumlar.size === 0) { log('Shard gonderimi icin once hesaplari baslat'); return }
  if (!Array.from(oturumlar.values()).some((x) => x.profil.alici)) { log('Shard alacak hesap girilmemis, takas yapilmaz'); return }
  for (const s of oturumlar.values()) if (s.bot) tradeIste(s, s.bot, 'elle')
})

channel.addListener('skor', () => {
  if (oturumlar.size === 0) { log('Skor tablosu icin once hesaplari baslat'); return }
  for (const s of oturumlar.values()) skorYazdir(s)
})

channel.addListener('sil', () => {
  elleDurduruldu = true
  hepsiniDurdur('kayitlar siliniyor')
  profilSil()
  log('Kayitli bilgiler silindi')
  durumGonder()
})

// nodejs-mobile'da yakalanmayan hata calisma ortamini kapatir ve yeniden baslatilamaz; bu yuzden yut ve yaz
process.on('uncaughtException', (e) => { log('Beklenmeyen hata: ' + (e && e.message)) })
process.on('unhandledRejection', (e) => { log('Beklenmeyen hata: ' + (e && e.message ? e.message : e)) })

log('AFK Bot hazir')
