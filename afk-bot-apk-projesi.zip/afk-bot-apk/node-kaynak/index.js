'use strict'
// AFK Bot - Node tarafi (nodejs-mobile icinde calisir).
// Yapimci: ShibaBey
// Arayuz (WebView) ile 'bridge' uzerinden mesajlasir. Birden cok AFK hesabi ayni anda calisabilir.

const { channel, getDataPath } = require('bridge')
const fs = require('fs')
const path = require('path')
const crypto = require('crypto')
const mineflayer = require('mineflayer')

// ====== SABIT AYARLAR ======
const A = {
  HOST: 'oyna.aesirmc.com',
  PORT: 25565,
  VERSION: false,               // gerekirse '1.20.1' gibi yaz
  LOGIN_BEKLEME: 5000,          // girisden kac ms sonra /login
  USEITEM_BEKLEME: 5000,        // /login'den kac ms sonra menu
  MENU_ESYA_SLOT: 1,            // lobide menu esyasinin hotbar slotu (1-9)
  SLOT: 30,                     // menude Prison'un slotu
  TIKLAMA_BEKLEME: 5000,        // menu acildiktan sonra tiklamadan once
  MENU_SONRASI_BEKLEME: 10000,  // Prison tiklandiktan sonra /warp afk'a kadar
  WARP_KOMUTU: '/warp afk',
  WARP_BEKLEME: 5000,           // /warp afk'tan sonra yuruyuse kadar
  WARP_TEKRAR: 2,               // isinlanma gorunmezse tekrar sayisi
  ISINLANMA_ESIK: 5,            // bu kadar blokdan az yer degistirdiyse isinlanma olmadi say
  YURUME_BLOK: 15,
  YURUME_ZAMAN_ASIMI: 20000,
  RESTART_SAAT: '06:05',        // restart sonrasi Prison'a gecis saati (Turkiye saati)
  TRADE_PAY: 100,               // tablodaki degerden en az bu kadar dusulur
  TRADE_ISINLANMA_BEKLEME: 10000,
  TRADE_ISTEK_BEKLEME: 5000,
  TRADE_PENCERE_ZAMAN_ASIMI: 40000,
  TRADE_ADIM_BEKLEME: 5000,
  TRADE_ONAY_SLOT: 45,          // onay blogu (46. slot = 45)
  TRADE_ONAY_BEKLEME: 6000,
  TRADE_SONRASI_BEKLEME: 5000,
  TRADE_ARALIK: 60000,
  HESAP_ARALIK: 5000,           // birden cok hesapta girisler arasi bekleme (sunucu baglanti sinirina takilmamak icin)
  TRADE_KALEMLER: [             // slot numaralari 0'dan baslar (2. slot = 1)
    { ad: 'JETON', anahtar: 'JETON', slot: 1, min: 1, aktif: true },
    { ad: 'MADEN RUHU', anahtar: 'MADEN RUHU', slot: 2, min: 1, aktif: true },
    { ad: 'MUCEVHER', anahtar: 'MUCEVHER', slot: 3, min: 1, aktif: true }
  ]
}
// ===========================

// ---------- Zaman (Turkiye UTC+3, Intl gerekmez) ----------
function simdi() {
  const d = new Date(Date.now() + 3 * 3600 * 1000)
  const p2 = (n) => String(n).padStart(2, '0')
  return {
    tarih: d.getUTCFullYear() + '-' + p2(d.getUTCMonth() + 1) + '-' + p2(d.getUTCDate()),
    saat: p2(d.getUTCHours()) + ':' + p2(d.getUTCMinutes()),
    saniyeli: p2(d.getUTCHours()) + ':' + p2(d.getUTCMinutes()) + ':' + p2(d.getUTCSeconds()),
    dk: d.getUTCHours() * 60 + d.getUTCMinutes(),
    sn: d.getUTCSeconds()
  }
}

// Restart penceresindeyse (hedeften 5 dk once ile hedef arasi) hedefe kalan ms, degilse 0
function hedefeKalanMs() {
  const t = simdi()
  const [hh, mm] = A.RESTART_SAAT.split(':').map(Number)
  const hedefDk = hh * 60 + mm
  if (t.dk >= hedefDk - 5 && t.dk < hedefDk) return ((hedefDk - t.dk) * 60 - t.sn) * 1000
  return 0
}

const bekle = (ms) => new Promise((r) => setTimeout(r, ms))

// ---------- Gunluk (arayuze gonderilir) ----------
const gunluk = []
function log(m, oturum) {
  const s = simdi().saniyeli + '  ' + (oturum ? '[' + oturum.profil.kullanici + '] ' : '') + m
  gunluk.push(s)
  if (gunluk.length > 400) gunluk.shift()
  try { channel.send('log', s) } catch (e) {}
}

// ---------- Kayit (AES-256-GCM, uygulamanin ozel klasorunde) ----------
const dosyaYolu = (ad) => path.join(getDataPath(), ad)

function anahtarAl() {
  const y = dosyaYolu('k.bin')
  try { return fs.readFileSync(y) } catch (e) {
    const k = crypto.randomBytes(32)
    fs.writeFileSync(y, k)
    return k
  }
}

let profilOnbellek = null
let profilYuklendi = false

function profilKaydet(profil) {
  const iv = crypto.randomBytes(12)
  const c = crypto.createCipheriv('aes-256-gcm', anahtarAl(), iv)
  const enc = Buffer.concat([c.update(JSON.stringify(profil), 'utf8'), c.final()])
  fs.writeFileSync(dosyaYolu('a.bin'), JSON.stringify({ iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), v: enc.toString('base64') }))
  profilOnbellek = profil
  profilYuklendi = true
}

// Kayit bicimi: { alici, otomatik, hesaplar: [{ kullanici, sifre }] }. Eski tek hesapli kayitlari da cevirir.
function profilOku() {
  if (profilYuklendi) return profilOnbellek
  let p = null
  try {
    const d = JSON.parse(fs.readFileSync(dosyaYolu('a.bin'), 'utf8'))
    const dc = crypto.createDecipheriv('aes-256-gcm', anahtarAl(), Buffer.from(d.iv, 'base64'))
    dc.setAuthTag(Buffer.from(d.tag, 'base64'))
    p = JSON.parse(Buffer.concat([dc.update(Buffer.from(d.v, 'base64')), dc.final()]).toString('utf8'))
    if (p && !Array.isArray(p.hesaplar) && p.kullanici) p = { alici: p.alici, otomatik: !!p.otomatik, hesaplar: [{ kullanici: p.kullanici, sifre: p.sifre }] }
    if (p && !Array.isArray(p.hesaplar)) p = null
  } catch (e) { p = null }
  profilOnbellek = p
  profilYuklendi = true
  return p
}

function profilSil() {
  try { fs.unlinkSync(dosyaYolu('a.bin')) } catch (e) {}
  profilOnbellek = null
  profilYuklendi = true
}

// ---------- Metin bilesenleri ve skor tablosu ----------
function nbtSade(x) {
  if (x && typeof x === 'object' && typeof x.type === 'string' && 'value' in x) {
    const t = x.type, v = x.value
    if (t === 'compound') { const o = {}; for (const k in v) o[k] = nbtSade(v[k]); return o }
    if (t === 'list') return (v.value || []).map((e) => nbtSade({ type: v.type, value: e }))
    return v
  }
  return x
}

function bilesenMetni(x) {
  if (x === null || x === undefined) return ''
  if (typeof x === 'string') {
    const t = x.trim()
    if (t[0] === '{' || t[0] === '[' || t[0] === '"') { try { return bilesenMetni(JSON.parse(t)) } catch (e) {} }
    return x
  }
  if (typeof x === 'number' || typeof x === 'boolean') return String(x)
  if (Array.isArray(x)) return x.map(bilesenMetni).join('')
  if (typeof x === 'object') {
    if (typeof x.type === 'string' && 'value' in x) return bilesenMetni(nbtSade(x))
    let s = ''
    if (typeof x.text === 'string') s += x.text
    else if (x.text !== undefined) s += bilesenMetni(x.text)
    if (!s && typeof x.translate === 'string') s += x.translate
    if (x.extra !== undefined) s += bilesenMetni(x.extra)
    return s
  }
  return ''
}

function skorTemizle(s) {
  return String(s).replace(/§[0-9a-fk-or]/gi, '').replace(/[\uE000-\uF8FF]/g, '').replace(/\s+/g, ' ').trim()
}

// ---------- Skor tablosu (her hesap icin ayri takip edilir) ----------
function bosSkor() { return { hedefler: {}, sidebar: null, skorlar: {}, takimlar: {}, oyuncuTakim: {} } }

function skorTakipBaslat(s, bot) {
  const c = bot._client
  if (!c) return
  const d = s.skor = bosSkor()
  c.on('scoreboard_objective', (p) => {
    if (p.action === 1) delete d.hedefler[p.name]
    else d.hedefler[p.name] = bilesenMetni(p.displayText)
  })
  c.on('scoreboard_display_objective', (p) => {
    if (p.position === 1 || p.position === 'sidebar') d.sidebar = p.name || null
  })
  c.on('scoreboard_score', (p) => {
    const hedef = p.scoreName !== undefined ? p.scoreName : p.objective_name
    const isim = p.itemName !== undefined ? p.itemName : p.entity_name
    if (hedef === undefined || isim === undefined) return
    if (p.action === 1) { if (d.skorlar[hedef]) delete d.skorlar[hedef][isim]; return }
    if (!d.skorlar[hedef]) d.skorlar[hedef] = {}
    d.skorlar[hedef][isim] = { deger: Number(p.value) || 0, gosterim: (p.display_name !== undefined && p.display_name !== null) ? bilesenMetni(p.display_name) : '' }
  })
  c.on('reset_score', (p) => {
    const hedef = p.scoreName !== undefined ? p.scoreName : (p.objective_name !== undefined ? p.objective_name : p.objectiveName)
    const isim = p.itemName !== undefined ? p.itemName : (p.entity_name !== undefined ? p.entity_name : p.entityName)
    if (isim === undefined) return
    if (hedef !== undefined && hedef !== null) { if (d.skorlar[hedef]) delete d.skorlar[hedef][isim] }
    else for (const h in d.skorlar) delete d.skorlar[h][isim]
  })
  const takimIsleyici = (p) => {
    const ad = p.team
    if (!ad) return
    const mod = typeof p.mode === 'number' ? ['add', 'remove', 'change', 'join', 'leave'][p.mode] : p.mode
    const oyuncular = Array.isArray(p.players) ? p.players : []
    if (mod === 'remove') {
      const t = d.takimlar[ad]
      if (t) t.oyuncular.forEach((o) => { delete d.oyuncuTakim[o] })
      delete d.takimlar[ad]
      return
    }
    let t = d.takimlar[ad]
    if (!t) t = d.takimlar[ad] = { prefix: '', suffix: '', oyuncular: [] }
    if (mod === 'add' || mod === 'change') { t.prefix = bilesenMetni(p.prefix); t.suffix = bilesenMetni(p.suffix) }
    if (mod === 'add' || mod === 'join') oyuncular.forEach((o) => { if (!t.oyuncular.includes(o)) t.oyuncular.push(o); d.oyuncuTakim[o] = ad })
    if (mod === 'leave') oyuncular.forEach((o) => { t.oyuncular = t.oyuncular.filter((x) => x !== o); delete d.oyuncuTakim[o] })
  }
  c.on('teams', takimIsleyici)
  c.on('scoreboard_team', takimIsleyici)
}

function skorSatirlari(s) {
  const d = s.skor
  const hedef = d.sidebar
  if (!hedef) return null
  const ogeler = Object.entries(d.skorlar[hedef] || {}).sort((a, b) => b[1].deger - a[1].deger)
  const satirlar = []
  for (const [isim, o] of ogeler) {
    let metin
    if (o.gosterim) metin = o.gosterim
    else {
      const t = d.takimlar[d.oyuncuTakim[isim]]
      metin = (t ? t.prefix : '') + isim + (t ? t.suffix : '')
    }
    const temiz = skorTemizle(metin)
    if (temiz) satirlar.push(temiz)
  }
  return { baslik: skorTemizle(d.hedefler[hedef] || hedef), satirlar }
}

function skorYazdir(s) {
  const t = skorSatirlari(s)
  if (!t) { log('Skor tablosu henuz gelmedi (Prison\'a gectikten sonra dene)', s); return }
  log('Skor tablosu: ' + t.baslik, s)
  t.satirlar.forEach((l) => log('   ' + l, s))
}

// ---------- Sayi cevirme (32.7K -> 32700) ----------
const KUCUK_HARF = { 'ᴀ': 'A', 'ʙ': 'B', 'ᴄ': 'C', 'ᴅ': 'D', 'ᴇ': 'E', 'ꜰ': 'F', 'ɢ': 'G', 'ʜ': 'H', 'ɪ': 'I', 'ᴊ': 'J', 'ᴋ': 'K', 'ʟ': 'L', 'ᴍ': 'M', 'ɴ': 'N', 'ᴏ': 'O', 'ᴘ': 'P', 'ǫ': 'Q', 'ʀ': 'R', 'ꜱ': 'S', 'ᴛ': 'T', 'ᴜ': 'U', 'ᴠ': 'V', 'ᴡ': 'W', 'ʏ': 'Y', 'ᴢ': 'Z', 'ı': 'I', 'İ': 'I', 'Ü': 'U', 'ü': 'U', 'Ö': 'O', 'ö': 'O', 'Ç': 'C', 'ç': 'C', 'Ş': 'S', 'ş': 'S', 'Ğ': 'G', 'ğ': 'G' }
const BIRIMLER = { '': 1, K: 1e3, M: 1e6, B: 1e9, T: 1e12 }

function duzYazi(s) {
  return String(s).split('').map((c) => KUCUK_HARF[c] || c).join('').toUpperCase()
}

function kisaSayiCoz(metin) {
  const m = String(metin).trim().match(/^([\d.,]+)\s*([A-Z]*)$/)
  if (!m) return null
  const birim = m[2]
  if (!(birim in BIRIMLER)) return null
  const sayi = birim ? m[1].replace(',', '.') : m[1].replace(/[.,]/g, '')
  const v = Number(sayi)
  if (!isFinite(v)) return null
  return Math.round(v * BIRIMLER[birim])
}

function kisaSayiAyrinti(metin) {
  const m = String(metin).trim().match(/^([\d.,]+)\s*([A-Z]*)$/)
  if (!m) return null
  const birim = m[2]
  if (!(birim in BIRIMLER)) return null
  let adim = 1
  if (birim) {
    const ondalik = m[1].replace(',', '.').split('.')[1]
    adim = BIRIMLER[birim] / Math.pow(10, ondalik ? ondalik.length : 0)
  }
  const sayi = kisaSayiCoz(metin)
  return sayi === null ? null : { sayi, adim }
}

function skorDegeri(s, anahtar) {
  const t = skorSatirlari(s)
  if (!t) return null
  const a = duzYazi(anahtar)
  for (const satir of t.satirlar) {
    const d = duzYazi(satir)
    const i = d.indexOf(a)
    if (i < 0) continue
    const kalan = d.slice(i + a.length).replace(/^[\s:]+/, '')
    const sayi = kisaSayiCoz(kalan)
    if (sayi !== null) return { satir, kalan, sayi }
  }
  return null
}

// Gonderilecek miktar = tablodaki deger - pay (pay en az TRADE_PAY, tablo cok yuvarlaksa yarim basamak)
function tradeHesap(s, anahtar) {
  const d = skorDegeri(s, anahtar)
  if (!d) return null
  const a = kisaSayiAyrinti(d.kalan)
  if (!a) return null
  const pay = Math.max(A.TRADE_PAY, Math.ceil(a.adim / 2))
  return { gosterilen: d.kalan, tablo: a.sayi, pay, gonderilecek: Math.max(0, a.sayi - pay) }
}

// ---------- Oturumlar (her AFK hesabi icin bir tane) ----------
let elleDurduruldu = false   // kullanici Durdur'a bastiysa uygulama yeniden acilana kadar otomatik baslatma yapma
const oturumlar = new Map()  // kucuk harfli kullanici adi -> oturum

function canli(s, bot) { return !!s && s.calisiyor && s.bot === bot && !!bot.entity }

function asamaYaz(s, asama) {
  s.asama = asama
  durumGonder()
}

function durumGonder() {
  const k = profilOku()
  const liste = ((k && k.hesaplar) || []).map((h) => {
    const s = oturumlar.get(h.kullanici.toLowerCase())
    return { kullanici: h.kullanici, sifreKayitli: !!h.sifre, calisiyor: !!(s && s.calisiyor), asama: s ? s.asama : 'Durdu' }
  })
  for (const s of oturumlar.values()) {
    if (!liste.some((h) => h.kullanici.toLowerCase() === s.profil.kullanici.toLowerCase())) liste.push({ kullanici: s.profil.kullanici, sifreKayitli: true, calisiyor: s.calisiyor, asama: s.asama })
  }
  try {
    channel.send('durum', {
      calisiyor: oturumlar.size > 0,
      calisanSayisi: oturumlar.size,
      kayitli: !!k,
      alici: k ? k.alici : '',
      otomatik: k ? !!k.otomatik : false,
      hesaplar: liste
    })
  } catch (e) {}
}

// ---------- Yurume ve warp ----------
function yuru(s, bot, hedef) {
  if (!bot.entity) { log('Yuruyus iptal: bot konumu yok', s); return }
  const bas = { x: bot.entity.position.x, z: bot.entity.position.z }
  const baslangicZamani = Date.now()
  let sonKonum = { x: bas.x, z: bas.z }
  let sonKontrol = Date.now()
  log('Yuruyus basladi (' + hedef + ' blok)', s)
  bot.setControlState('forward', true)
  const sayac = setInterval(() => {
    if (!canli(s, bot)) { clearInterval(sayac); try { bot.setControlState('forward', false) } catch (e) {} return }
    const p = bot.entity.position
    const gidilen = Math.hypot(p.x - bas.x, p.z - bas.z)
    const durdur = (sebep) => {
      clearInterval(sayac)
      bot.setControlState('forward', false)
      bot.setControlState('jump', false)
      log(sebep + ': ' + gidilen.toFixed(1) + ' blok', s)
    }
    if (gidilen >= hedef) { durdur('Yuruyus bitti'); return }
    if (Date.now() - baslangicZamani > A.YURUME_ZAMAN_ASIMI) { durdur('Yuruyus zaman asimi'); return }
    if (Date.now() - sonKontrol > 1500) {
      const ilerleme = Math.hypot(p.x - sonKonum.x, p.z - sonKonum.z)
      bot.setControlState('jump', ilerleme < 0.3)
      sonKonum = { x: p.x, z: p.z }
      sonKontrol = Date.now()
    }
  }, 100)
}

// /warp afk yazar, konum degisimiyle isinlandigini dogrular, olmadiysa tekrar dener, sonra devam eder
function warpGit(s, bot, deneme, sonra) {
  const once = bot.entity ? { x: bot.entity.position.x, y: bot.entity.position.y, z: bot.entity.position.z } : null
  try { bot.chat(A.WARP_KOMUTU); log(A.WARP_KOMUTU + ' gonderildi' + (deneme > 0 ? ' (tekrar ' + deneme + ')' : ''), s) } catch (e) {}
  setTimeout(() => {
    if (!canli(s, bot)) return
    let tasindi = true
    if (once && bot.entity) {
      const p = bot.entity.position
      const mesafe = Math.hypot(p.x - once.x, p.y - once.y, p.z - once.z)
      tasindi = mesafe >= A.ISINLANMA_ESIK
      log('Isinlanma kontrolu: ' + mesafe.toFixed(1) + ' blok ' + (tasindi ? '(tamam)' : '(isinlanma gorunmuyor)'), s)
    }
    if (!tasindi && deneme < A.WARP_TEKRAR) { warpGit(s, bot, deneme + 1, sonra); return }
    sonra()
  }, A.WARP_BEKLEME)
}

// ---------- Takas (trade) ----------
function pencereBasligi(w) { return w ? skorTemizle(bilesenMetni(w.title)) : '' }
function takasPencereMi(w) { return !!w && duzYazi(pencereBasligi(w)).includes('TAKAS') }

function takasKarsiTaraf(w) {
  const t = pencereBasligi(w)
  const i = duzYazi(t).indexOf('TAKAS')
  if (i < 0) return ''
  return t.slice(i + 5).replace(/^[\s:]+/, '').split(/\s+/)[0] || ''
}

async function tradePencereBekle(s, bot, kosul, ms) {
  const bitis = Date.now() + ms
  while (Date.now() < bitis) {
    if (!canli(s, bot)) return false
    if (kosul(bot.currentWindow)) return true
    await bekle(250)
  }
  return false
}

function tradeTabelaBekle(bot, ms) {
  return new Promise((coz) => {
    const c = bot._client
    let bitti = false
    const dinle = (p) => { if (bitti) return; bitti = true; clearTimeout(z); coz(p) }
    const z = setTimeout(() => { if (bitti) return; bitti = true; c.removeListener('open_sign_entity', dinle); coz(null) }, ms)
    c.once('open_sign_entity', dinle)
  })
}

function tradeTabelaYaz(bot, p, metin) {
  bot._client.write('update_sign', { location: p.location, isFrontText: p.isFrontText !== undefined ? p.isFrontText : true, text1: metin, text2: '', text3: '', text4: '' })
}

function tradeIptal(s, bot, sebep) {
  log('TAKAS IPTAL: ' + sebep, s)
  try { if (bot.currentWindow) bot.closeWindow(bot.currentWindow) } catch (e) {}
}

async function tradeAfkaDon(s, bot) {
  if (!canli(s, bot)) { log('AFK donus iptal: bot sunucuda degil', s); return }
  try { if (bot.currentWindow) bot.closeWindow(bot.currentWindow) } catch (e) {}
  log('Takas bitti, ' + (A.TRADE_SONRASI_BEKLEME / 1000) + ' sn sonra ' + A.WARP_KOMUTU + ' ile AFK bolgesine donuluyor', s)
  await bekle(A.TRADE_SONRASI_BEKLEME)
  if (!canli(s, bot)) return
  asamaYaz(s, 'AFK bolgesine donuluyor')
  await new Promise((coz) => {
    warpGit(s, bot, 0, () => { yuru(s, bot, A.YURUME_BLOK); asamaYaz(s, 'AFK bolgesinde'); coz() })
    setTimeout(coz, 60000)
  })
}

// Ayni anda yalnizca tek hesap takas yapar (alici hesap ayni anda iki takasta olamaz); digerleri sirada bekler.
let tradeKuyruk = Promise.resolve()
let tradeKuyrukSayisi = 0

function tradeIste(s, bot, kaynak) {
  if (!canli(s, bot)) { log('Takas yapilamadi: bot sunucuda degil', s); return }
  if (s.tradeMesgul || s.tradeSirada) { log('Takas zaten suruyor ya da sirada', s); return }
  const gecen = Date.now() - s.sonTradeZamani
  if (gecen < A.TRADE_ARALIK) { log('Takas cok sik istendi, ' + Math.ceil((A.TRADE_ARALIK - gecen) / 1000) + ' sn sonra tekrar dene', s); return }
  s.tradeSirada = true
  if (tradeKuyrukSayisi > 0) log('Takas sirada: onunde ' + tradeKuyrukSayisi + ' hesap var (ayni anda tek takas yapilir)', s)
  tradeKuyrukSayisi++
  tradeKuyruk = tradeKuyruk
    .then(() => tradeCalistir(s, bot, kaynak))
    .catch(() => {})
    .then(() => { tradeKuyrukSayisi-- })
}

async function tradeCalistir(s, bot, kaynak) {
  s.tradeSirada = false
  if (!canli(s, bot)) { log('Takas yapilamadi: bot sunucuda degil', s); return }
  const alici = s.profil.alici
  s.tradeMesgul = true
  s.sonTradeZamani = Date.now()
  try {
    asamaYaz(s, 'Takas yapiliyor')
    log('TAKAS basladi (' + kaynak + ') -> alici: ' + alici, s)
    bot.chat('/tpa ' + alici)
    log('/tpa ' + alici + ' gonderildi, ' + (A.TRADE_ISINLANMA_BEKLEME / 1000) + ' sn bekleniyor', s)
    await bekle(A.TRADE_ISINLANMA_BEKLEME)
    if (!canli(s, bot)) return
    bot.chat('/trade ' + alici)
    log('/trade ' + alici + ' gonderildi, ' + (A.TRADE_ISTEK_BEKLEME / 1000) + ' sn bekleniyor', s)
    await bekle(A.TRADE_ISTEK_BEKLEME)

    if (!(await tradePencereBekle(s, bot, takasPencereMi, A.TRADE_PENCERE_ZAMAN_ASIMI))) { tradeIptal(s, bot, 'takas ekrani acilmadi (istek kabul edilmedi mi?)'); return }
    const karsi = takasKarsiTaraf(bot.currentWindow)
    if (duzYazi(karsi) !== duzYazi(alici)) { tradeIptal(s, bot, 'takas ekrani baska biriyle acildi: "' + karsi + '" (sadece ' + alici + ')'); return }
    log('Takas ekrani acildi: ' + pencereBasligi(bot.currentWindow), s)

    let gonderilen = 0
    for (const k of A.TRADE_KALEMLER) {
      if (!k.aktif) continue
      const h = tradeHesap(s, k.anahtar)
      if (!h) { log('TAKAS: ' + k.ad + ' skor tablosunda okunamadi, atlandi', s); continue }
      if (h.gonderilecek < k.min) { log('TAKAS: ' + k.ad + ' cok az (' + h.gosterilen + '), atlandi', s); continue }
      if (!takasPencereMi(bot.currentWindow) && !(await tradePencereBekle(s, bot, takasPencereMi, 10000))) { tradeIptal(s, bot, 'takas ekrani kapandi'); return }
      if (duzYazi(takasKarsiTaraf(bot.currentWindow)) !== duzYazi(alici)) { tradeIptal(s, bot, 'karsi taraf degisti'); return }
      log('TAKAS: ' + k.ad + ' -> tabloda ' + h.gosterilen + ' (' + h.tablo + ') - ' + h.pay + ' = ' + h.gonderilecek, s)
      const tabela = tradeTabelaBekle(bot, 10000)
      bot.clickWindow(k.slot, 0, 0).catch(() => {})
      const p = await tabela
      if (!p) { tradeIptal(s, bot, 'tabela ekrani acilmadi (' + k.ad + ', slot ' + k.slot + ')'); return }
      await bekle(1000)
      tradeTabelaYaz(bot, p, String(h.gonderilecek))
      log('Tabelaya yazildi: ' + h.gonderilecek, s)
      gonderilen++
      await bekle(A.TRADE_ADIM_BEKLEME)
    }
    if (gonderilen === 0) { tradeIptal(s, bot, 'gonderilecek bir sey yok'); return }

    if (!takasPencereMi(bot.currentWindow) && !(await tradePencereBekle(s, bot, takasPencereMi, 10000))) { tradeIptal(s, bot, 'onay oncesi takas ekrani kapandi'); return }
    bot.clickWindow(A.TRADE_ONAY_SLOT, 0, 0).catch(() => {})
    log('Onay verildi (slot ' + A.TRADE_ONAY_SLOT + '), ' + (A.TRADE_ONAY_BEKLEME / 1000) + ' sn bekleniyor', s)
    await bekle(A.TRADE_ONAY_BEKLEME)
    if (await tradePencereBekle(s, bot, (w) => !takasPencereMi(w), 30000)) log('TAKAS tamamlandi (takas ekrani kapandi)', s)
    else log('TAKAS: takas ekrani hala acik, karsi tarafin onayi bekleniyor olabilir', s)
  } catch (e) {
    log('TAKAS hata: ' + e.message, s)
    try { if (bot.currentWindow) bot.closeWindow(bot.currentWindow) } catch (x) {}
  } finally {
    try { await tradeAfkaDon(s, bot) } catch (e) { log('AFK donus hatasi: ' + e.message, s) }
    s.tradeMesgul = false
  }
}

// Ozel mesaj "<alici> ... trade" ise takasi baslatir (sadece alici hesaptan)
function tradeMesajKontrol(s, bot, msg) {
  const temiz = skorTemizle(msg)
  if (!/trade/i.test(temiz)) return
  const ad = s.profil.alici.replace(/[^A-Za-z0-9_]/g, '')
  const uygun = new RegExp('^[^A-Za-z0-9_]*' + ad + '(?![A-Za-z0-9_])', 'i').test(temiz) && /\btrade\s*$/i.test(temiz)
  if (uygun) { log('Takas mesaji alindi: ' + temiz, s); tradeIste(s, bot, 'mesaj') }
}

// ---------- Baglanti ve AFK dongusu ----------
function prisonAkisi(s, bot, kaynak) {
  if (!canli(s, bot)) return
  if (Date.now() - s.sonAkisZamani < 120000) return
  s.sonAkisZamani = Date.now()
  s.tiklandi = false
  log('Prison akisi basladi (' + kaynak + ')', s)
  asamaYaz(s, 'Prison\'a geciliyor')
  try { bot.setQuickBarSlot(A.MENU_ESYA_SLOT - 1) } catch (e) {}
  setTimeout(() => {
    if (!canli(s, bot)) return
    try { s.useitemGitti = true; bot.activateItem(); log('Menu acildi (useitem)', s) } catch (e) {}
  }, 500)
}

function baglan(s) {
  if (!s.calisiyor) return
  asamaYaz(s, 'Baglaniyor')
  log('Baglaniyor: ' + A.HOST, s)
  const bot = mineflayer.createBot({
    host: A.HOST,
    port: A.PORT,
    username: s.profil.kullanici,
    auth: 'offline',
    ...(A.VERSION ? { version: A.VERSION } : {})
  })
  s.bot = bot
  s.girisYapildi = false
  s.useitemGitti = false
  s.tiklandi = false
  skorTakipBaslat(s, bot)
  bot.on('messagestr', (m, p) => { if (p !== 'game_info') tradeMesajKontrol(s, bot, m) })

  bot.on('spawn', () => {
    if (!s.calisiyor || s.bot !== bot || s.girisYapildi) return
    s.girisYapildi = true
    log('Sunucuya girildi', s)
    asamaYaz(s, 'Giris yapiliyor')
    setTimeout(() => {
      if (!canli(s, bot)) return
      try { bot.chat('/login ' + s.profil.sifre); log('/login gonderildi', s) } catch (e) {}
    }, A.LOGIN_BEKLEME)
    const normal = A.LOGIN_BEKLEME + A.USEITEM_BEKLEME
    const restart = hedefeKalanMs()
    if (restart > normal) log('Restart saati bekleniyor: ' + A.RESTART_SAAT + ' (' + Math.round(restart / 1000) + ' sn)', s)
    setTimeout(() => prisonAkisi(s, bot, 'giris'), Math.max(normal, restart))
  })

  bot.on('windowOpen', () => {
    if (!canli(s, bot) || !s.useitemGitti || s.tiklandi) return
    if (s.tradeMesgul) return
    s.tiklandi = true
    setTimeout(async () => {
      if (!canli(s, bot)) return
      try {
        await bot.clickWindow(A.SLOT, 0, 0)
        log('Slot ' + A.SLOT + ' tiklandi (Prison)', s)
      } catch (e) {
        log('Tiklama hatasi: ' + e.message, s)
        return
      }
      setTimeout(() => {
        if (!canli(s, bot)) return
        asamaYaz(s, 'Warp AFK\'ya gidiliyor')
        warpGit(s, bot, 0, () => { yuru(s, bot, A.YURUME_BLOK); asamaYaz(s, 'AFK bolgesinde') })
      }, A.MENU_SONRASI_BEKLEME)
    }, A.TIKLAMA_BEKLEME)
  })

  bot.on('kicked', (r) => log('Atildi: ' + skorTemizle(bilesenMetni(r)), s))
  bot.on('error', (e) => log('Hata: ' + e.message, s))
  bot.on('end', () => {
    if (!s.calisiyor || s.bot !== bot) return
    asamaYaz(s, 'Yeniden baglaniyor')
    log('Baglanti koptu, 10 sn sonra tekrar denenecek', s)
    s.timer = setTimeout(() => baglan(s), 10000)
  })
}

// gecikme > 0 ise hesap "Sirada" olarak gorunur ve o kadar sonra baglanir (sunucu baglanti sinirina takilmamak icin)
function hesapBaslat(h, alici, kaynak, gecikme) {
  const anahtar = h.kullanici.toLowerCase()
  if (oturumlar.has(anahtar)) return
  const s = {
    profil: { kullanici: h.kullanici, sifre: h.sifre, alici },
    bot: null, calisiyor: true, asama: gecikme ? 'Sirada' : 'Baslatiliyor', timer: null,
    tradeMesgul: false, tradeSirada: false, sonTradeZamani: 0, sonAkisZamani: 0, sonZamanlayiciTarih: '',
    girisYapildi: false, useitemGitti: false, tiklandi: false, skor: bosSkor()
  }
  oturumlar.set(anahtar, s)
  log('Baslatildi (' + kaynak + ')' + (gecikme ? ', ' + Math.round(gecikme / 1000) + ' sn sonra baglanacak' : ''), s)
  s.timer = setTimeout(() => baglan(s), gecikme)
}

function hepsiniBaslat(profil, kaynak) {
  let sira = 0
  for (const h of profil.hesaplar) {
    if (oturumlar.has(h.kullanici.toLowerCase())) continue
    hesapBaslat(h, profil.alici, kaynak, sira * A.HESAP_ARALIK)
    sira++
  }
  if (profil.hesaplar.length > 10) log('Uyari: ' + profil.hesaplar.length + ' hesap telefonu yorabilir')
  durumGonder()
}

function hesapDurdur(s, sebep) {
  s.calisiyor = false
  clearTimeout(s.timer)
  s.asama = 'Durdu'
  try { if (s.bot) s.bot.quit() } catch (e) {}
  oturumlar.delete(s.profil.kullanici.toLowerCase())
  log('Durduruldu' + (sebep ? ' (' + sebep + ')' : ''), s)
}

function hepsiniDurdur(sebep) {
  for (const s of Array.from(oturumlar.values())) hesapDurdur(s, sebep)
  durumGonder()
}

// Her gun RESTART_SAAT'te bagli her hesap icin Prison akisini bastan calistir
setInterval(() => {
  const t = simdi()
  if (t.saat !== A.RESTART_SAAT) return
  for (const s of oturumlar.values()) {
    if (!s.calisiyor || s.sonZamanlayiciTarih === t.tarih) continue
    s.sonZamanlayiciTarih = t.tarih
    if (s.bot && canli(s, s.bot) && !s.tradeMesgul) {
      log('Zamanlayici ' + A.RESTART_SAAT + ': lobiden Prison\'a geciliyor', s)
      prisonAkisi(s, s.bot, 'zamanlayici')
    } else {
      log('Zamanlayici ' + A.RESTART_SAAT + ': bagli degil, baglaninca akis kendiliginden calisir', s)
    }
  }
}, 10000)

// ---------- Arayuzden gelen mesajlar ----------
const adGecerli = (s) => /^[A-Za-z0-9_]{3,16}$/.test(s || '')

channel.addListener('hazir', () => {
  channel.send('gecmis', gunluk.slice())
  durumGonder()
  const k = profilOku()
  if (k && k.otomatik && oturumlar.size === 0 && !elleDurduruldu) hepsiniBaslat(k, 'otomatik baslatma')
})

channel.addListener('baslat', (veri) => {
  try {
    veri = veri || {}
    const gelen = Array.isArray(veri.hesaplar) ? veri.hesaplar : []
    if (gelen.length === 0) { channel.send('hata', 'En az bir AFK hesabi ekle.'); return }
    if (!adGecerli(veri.alici)) { channel.send('hata', 'Takas alacak hesap adi 3-16 karakter olmali (harf, rakam, alt cizgi).'); return }
    const kayit = profilOku()
    const kayitliSifre = (ad) => {
      const h = kayit && kayit.hesaplar.find((x) => x.kullanici.toLowerCase() === ad.toLowerCase())
      return h ? h.sifre : ''
    }
    const gorulen = new Set()
    const hesaplar = []
    for (const h of gelen) {
      const ad = String((h && h.kullanici) || '').trim()
      if (!adGecerli(ad)) { channel.send('hata', '"' + ad + '" gecerli bir hesap adi degil (3-16 karakter, harf, rakam, alt cizgi).'); return }
      if (gorulen.has(ad.toLowerCase())) { channel.send('hata', ad + ' hesabi birden fazla kez eklenmis.'); return }
      if (ad.toLowerCase() === String(veri.alici).toLowerCase()) { channel.send('hata', 'Takas alacak hesap (' + ad + ') AFK hesaplarindan biri olamaz.'); return }
      let sifre = String((h && h.sifre) || '')
      if (!sifre) sifre = kayitliSifre(ad)
      if (!sifre) { channel.send('hata', ad + ' icin sifre girilmeli.'); return }
      if (sifre.length > 64 || /\s/.test(sifre)) { channel.send('hata', ad + ' sifresi bosluk icermemeli ve en fazla 64 karakter olmali.'); return }
      gorulen.add(ad.toLowerCase())
      hesaplar.push({ kullanici: ad, sifre })
    }
    const profil = { alici: String(veri.alici), otomatik: !!veri.otomatik, hesaplar }
    profilKaydet(profil)
    elleDurduruldu = false
    hepsiniBaslat(profil, 'elle')
  } catch (e) { channel.send('hata', 'Baslatilamadi: ' + e.message) }
})

channel.addListener('durdur', () => { elleDurduruldu = true; hepsiniDurdur('elle') })

channel.addListener('trade', () => {
  if (oturumlar.size === 0) { log('Takas icin once hesaplari baslat'); return }
  for (const s of oturumlar.values()) if (s.bot) tradeIste(s, s.bot, 'elle')
})

channel.addListener('skor', () => {
  if (oturumlar.size === 0) { log('Skor tablosu icin once hesaplari baslat'); return }
  for (const s of oturumlar.values()) skorYazdir(s)
})

channel.addListener('sil', () => {
  elleDurduruldu = true
  hepsiniDurdur('kayitlar siliniyor')
  profilSil()
  log('Kayitli bilgiler silindi')
  durumGonder()
})

// nodejs-mobile'da yakalanmayan hata calisma ortamini kapatir ve yeniden baslatilamaz; bu yuzden yut ve yaz
process.on('uncaughtException', (e) => { log('Beklenmeyen hata: ' + (e && e.message)) })
process.on('unhandledRejection', (e) => { log('Beklenmeyen hata: ' + (e && e.message ? e.message : e)) })

log('AFK Bot hazir')
